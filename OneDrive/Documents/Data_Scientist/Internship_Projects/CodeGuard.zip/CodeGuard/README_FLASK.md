# CodeGuard AI - Elite Security Intelligence (Flask Edition)

🛡️ **Advanced Static Code Analysis with Beautiful UI**

A powerful Flask-based security analysis tool that identifies vulnerabilities in Python code and provides AI-powered secure code reconstruction.

## ✨ Features

- **Neural Security Analysis**: Advanced static analysis using multiple security engines
- **Beautiful Modern UI**: Glass morphism design with Monaco Editor
- **AI-Powered Code Fixing**: Automatic secure code generation
- **Real-time Analysis**: Instant feedback on security vulnerabilities
- **MongoDB Integration**: Optional database persistence for audit history
- **Responsive Design**: Works perfectly on desktop and mobile devices

## 🚀 Quick Start

### Prerequisites
- Python 3.8+
- MongoDB (optional, for audit history)

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd CodeGuard
   ```

2. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Run the application**
   ```bash
   python flask_server.py
   ```

4. **Open your browser**
   Navigate to `http://localhost:5001`

## 🎯 Usage

1. **Paste your Python code** into the Monaco editor
2. **Click "INITIALIZE SCAN"** or press `Ctrl+Enter`
3. **Review security findings** in the SEC-OPS feed
4. **Generate secure code** using the AI-powered reconstruction feature

## 🔧 Configuration

### Environment Variables
```bash
# Optional MongoDB connection
MONGO_URI=mongodb://localhost:27017/codeguard_flask

# Flask configuration
FLASK_ENV=production
FLASK_DEBUG=False
```

### Database Setup (Optional)
If you want audit history persistence:

1. Install MongoDB
2. Set the `MONGO_URI` environment variable
3. The application will automatically create the required collections

## 🏗️ Architecture

```
CodeGuard Flask/
├── flask_server.py          # Main Flask application
├── templates/
│   └── index.html          # Main UI template
├── static/
│   ├── style.css           # Beautiful UI styles
│   ├── app.js              # Frontend JavaScript
│   └── sw.js               # Service worker
├── analyzer/               # Security analysis engine
├── rules/                  # Security rules
├── report/                 # Report generation
└── requirements.txt        # Python dependencies
```

## 🛡️ Security Engines

- **Bandit**: Python security linter
- **Safety**: Dependency vulnerability scanner
- **Semgrep**: Static analysis rules
- **Custom Rules**: Proprietary security patterns

## 🎨 UI Features

- **Glass Morphism Design**: Modern, beautiful interface
- **Monaco Editor**: Professional code editor with syntax highlighting
- **Real-time Metrics**: Live threat counters
- **Animated Feedback**: Smooth transitions and loading states
- **Responsive Layout**: Works on all screen sizes
- **Dark Theme**: Easy on the eyes for long coding sessions

## 📊 API Endpoints

- `GET /` - Main application interface
- `POST /api/analyze` - Analyze code for security vulnerabilities
- `POST /api/fix` - Generate secure code reconstruction
- `GET /api/history` - Retrieve analysis history (requires MongoDB)
- `GET /api/status` - System health check

## 🔍 Example Analysis

The tool can detect various security issues:
- SQL Injection vulnerabilities
- Command injection flaws
- Hardcoded credentials
- Insecure deserialization
- Path traversal vulnerabilities
- And many more...

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📝 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🆘 Support

For issues and questions:
1. Check the existing issues
2. Create a new issue with detailed information
3. Include code samples and error messages

---

**Made with ❤️ for secure coding practices**
