import ast
import sys
import os
from typing import List, Union, Optional
from .file_handler import FileHandler
from .parser import parse_code
from rules import DangerousFunctionsRule, HardcodedCredentialsRule, WeakHashingRule, Rule
from report.report import Report, Finding

class Analyzer:
    """
    Optimized static code analysis engine for fast processing.
    """
    def __init__(self) -> None:
        self.file_handler: FileHandler = FileHandler()
        # Reduced rule set for faster processing
        self.rules: List[Rule] = [
            DangerousFunctionsRule(),
            HardcodedCredentialsRule(),
            WeakHashingRule()
        ]
        self.report: Report = Report()

    def run(self, paths: Union[str, List[str]], quiet: bool = True) -> Report:
        """
        Fast analysis pipeline optimized for web interface.
        """
        # Reset report for new analysis
        self.report = Report()
        
        files: List[str] = self.file_handler.collect_files(paths)
        if not files:
            if not quiet: print("No Python files found to analyze.")
            return self.report

        if not quiet: print(f"Analyzing {len(files)} files...")

        for file_path in files:
            self.report.increment_file_count()
            
            try:
                # Fast file reading with size limit for web interface
                code: Optional[str] = self._read_file_fast(file_path)
                if code is None:
                    self.report.add_error(file_path, "IOError", "Failed to read file or file too large.")
                    continue

                # Quick parse with timeout protection
                parse_result = self._parse_code_fast(code)
                if parse_result['error']:
                    err = parse_result['error']
                    self.report.add_error(file_path, err['type'], err['message'], err.get('lineno', 0))
                    continue

                tree: ast.Module = parse_result['tree']
                
                # Optimized AST traversal - limit depth and nodes
                self._analyze_tree_fast(tree, file_path)
                
            except Exception as e:
                self.report.add_error(file_path, "AnalysisError", f"Analysis failed: {str(e)}")
                continue

        return self.report

    def _read_file_fast(self, file_path: str, max_size: int = 1024 * 1024) -> Optional[str]:
        """Fast file reading with size limits."""
        try:
            # Check file size first
            if os.path.getsize(file_path) > max_size:
                return None
                
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                return f.read()
        except Exception:
            return None

    def _parse_code_fast(self, code: str) -> dict:
        """Fast code parsing with error handling."""
        try:
            # Limit code length for web interface
            if len(code) > 50000:  # 50KB limit
                code = code[:50000]
                
            tree = ast.parse(code)
            return {'tree': tree, 'error': None}
        except SyntaxError as e:
            return {
                'tree': None,
                'error': {
                    'type': 'SyntaxError',
                    'message': str(e),
                    'lineno': getattr(e, 'lineno', 0)
                }
            }
        except Exception as e:
            return {
                'tree': None,
                'error': {
                    'type': 'ParseError',
                    'message': str(e),
                    'lineno': 0
                }
            }

    def _analyze_tree_fast(self, tree: ast.Module, file_path: str) -> None:
        """Optimized AST analysis with node limits."""
        node_count = 0
        max_nodes = 10000  # Limit nodes to prevent long processing
        
        try:
            for node in ast.walk(tree):
                node_count += 1
                if node_count > max_nodes:
                    break
                    
                # Quick rule checking
                for rule in self.rules:
                    try:
                        result = rule.check(node)
                        if result:
                            finding = Finding(
                                file=file_path,
                                line=result.get("line", 0),
                                column=result.get("column", 0),
                                rule_name=rule.__class__.__name__,
                                message=result.get("message", "N/A"),
                                severity=rule.severity,
                                description=rule.description,
                                remediation=rule.remediation,
                                potential_impact=rule.potential_impact
                            )
                            self.report.add_finding(finding)
                    except Exception:
                        # Skip rule errors for speed
                        continue
                        
        except Exception:
            # Skip traversal errors for speed
            pass
