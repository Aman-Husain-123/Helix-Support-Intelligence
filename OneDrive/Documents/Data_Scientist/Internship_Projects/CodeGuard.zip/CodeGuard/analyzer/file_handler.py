import os
import sys
from typing import List, Optional, Union, Set

class FileHandler:
    def __init__(self) -> None:
        self.files: List[str] = []

    def collect_files(self, paths: Union[str, List[str]]) -> List[str]:
        """
        Recursively collects all .py files from the provided paths.
        Args:
            paths: List of file or directory paths or a single path string.
        Returns:
            List of absolute paths to .py files found.
        """
        collected: Set[str] = set()
        
        # Ensure paths is iterable
        path_list: List[str] = [paths] if isinstance(paths, str) else paths

        for path in path_list:
            abs_path: str = os.path.abspath(path)
            
            if not os.path.exists(abs_path):
                print(f"Warning: Path does not exist: {abs_path}", file=sys.stderr)
                continue

            if os.path.isfile(abs_path):
                if abs_path.endswith('.py'):
                    collected.add(abs_path)
            elif os.path.isdir(abs_path):
                try:
                    for root, _, files in os.walk(abs_path):
                        for file in files:
                            if file.endswith('.py'):
                                collected.add(os.path.join(root, file))
                except PermissionError:
                     print(f"Error: Permission denied accessing directory: {abs_path}", file=sys.stderr)
            else:
                 print(f"Warning: Path is not a standard file or directory: {abs_path}", file=sys.stderr)

        self.files = list(collected)
        return self.files

    def read_file(self, file_path: str) -> Optional[str]:
        """
        Reads the content of the specified file.
        Args:
            file_path: The path to the file to read.
        Returns:
            The content of the file, or None if an error occurs.
        """
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return f.read()
        except FileNotFoundError:
            print(f"Error: File not found: {file_path}", file=sys.stderr)
        except PermissionError:
            print(f"Error: Permission denied reading file: {file_path}", file=sys.stderr)
        except UnicodeDecodeError:
             print(f"Error: Unable to decode file (not UTF-8): {file_path}", file=sys.stderr)
        except Exception as e:
            print(f"Error reading file {file_path}: {e}", file=sys.stderr)
        
        return None
