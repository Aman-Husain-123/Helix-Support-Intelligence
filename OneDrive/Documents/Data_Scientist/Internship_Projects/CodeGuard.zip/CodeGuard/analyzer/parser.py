import ast
from typing import Dict, Any, Optional

def parse_code(code: str) -> Dict[str, Any]:
    """
    Parses the given Python code string into an abstract syntax tree (AST).
    
    Args:
        code: The Python source code to parse.

    Returns:
        Dict: A dictionary with 'tree' and 'error' keys.
    """
    try:
        tree = ast.parse(code)
        return {
            "tree": tree,
            "error": None
        }
    except SyntaxError as e:
        return {
            "tree": None,
            "error": {
                "type": "SyntaxError",
                "message": e.msg,
                "lineno": e.lineno,
                "offset": e.offset,
                "text": e.text
            }
        }
    except ValueError as e:
        return {
            "tree": None,
            "error": {
                "type": "ValueError",
                "message": str(e),
                "lineno": None,
                "offset": None,
                "text": None
            }
        }
    except Exception as e:
        return {
            "tree": None,
            "error": {
                "type": type(e).__name__,
                "message": str(e),
                "lineno": None,
                "offset": None,
                "text": None
            }
        }
