import ast
from typing import Set

class SecureFixer:
    """
    Experimental engine to automatically propose secure alternatives for detected vulnerabilities.
    Uses built-in AST-to-Source transformation (Python 3.9+).
    """
    def __init__(self) -> None:
        self.secret_keywords: Set[str] = {'password', 'secret', 'api_key', 'token', 'db', 'url', 'database', 'conn', 'cred', 'login', 'pass', 'hash', 'key'}
        self.weak_hashes: Set[str] = {'md5', 'sha1'}
        self.dangerous_funcs: Set[str] = {'eval', 'exec'}

    def fix_code(self, source_code: str) -> str:
        try:
            tree = ast.parse(source_code)
            transformer = SecurityTransformer(self.secret_keywords, self.weak_hashes, self.dangerous_funcs)
            new_tree = transformer.visit(tree)
            ast.fix_missing_locations(new_tree)
            
            # Use built-in ast.unparse (Available in Python 3.9+)
            fixed_code = ast.unparse(new_tree)
            
            # Add imports if they were used in fixes
            imports_to_add = []
            if transformer.used_os and "import os" not in source_code: 
                imports_to_add.append("import os")
            if transformer.used_ast and "import ast" not in source_code: 
                imports_to_add.append("import ast")
            if transformer.used_hashlib and "import hashlib" not in source_code:
                 imports_to_add.append("import hashlib")

            if imports_to_add:
                fixed_code = "\n".join(imports_to_add) + "\n\n" + fixed_code
            
            return fixed_code
        except Exception as e:
            return f"# ERROR GENERATING SECURE CODE: {e}\n\n{source_code}"

class SecurityTransformer(ast.NodeTransformer):
    def __init__(self, secret_keys, weak_hashes, danger_funcs):
        self.secret_keys = secret_keys
        self.weak_hashes = weak_hashes
        self.danger_funcs = danger_funcs
        self.used_os = False
        self.used_ast = False
        self.used_hashlib = False

    def visit_Assign(self, node: ast.Assign):
        # S002: Hardcoded Secrets
        if isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
            for target in node.targets:
                if isinstance(target, ast.Name):
                    var_name = target.id.lower()
                    if any(key in var_name for key in self.secret_keys):
                        self.used_os = True
                        # Replace with os.getenv('VAR_NAME', 'FALLBACK')
                        new_value = ast.Call(
                            func=ast.Attribute(
                                value=ast.Name(id='os', ctx=ast.Load()),
                                attr='getenv',
                                ctx=ast.Load()
                            ),
                            args=[
                                ast.Constant(value=target.id.upper()),
                                ast.Constant(value="REPLACE_WITH_SECURE_VAL")
                            ],
                            keywords=[]
                        )
                        return ast.Assign(targets=node.targets, value=new_value)
        return self.generic_visit(node)

    def visit_Call(self, node: ast.Call):
        # S001: Dangerous Functions
        if isinstance(node.func, ast.Name) and node.func.id in self.danger_funcs:
            if node.func.id == 'eval':
                self.used_ast = True
                # Replace eval(x) with ast.literal_eval(x)
                node.func = ast.Attribute(
                    value=ast.Name(id='ast', ctx=ast.Load()),
                    attr='literal_eval',
                    ctx=ast.Load()
                )
            elif node.func.id == 'exec':
                # Suggest manual review for exec
                return ast.Expr(value=ast.Constant(value=f"# SECURE_MANUAL_REVIEW_REQUIRED: Dynamic execution (exec) removed for security."))

        # S003: Weak Hashing
        func_name = ""
        # Check for hashlib.md5 style
        if isinstance(node.func, ast.Attribute) and node.func.attr in self.weak_hashes:
            self.used_hashlib = True
            # Replace hashlib.md5 with hashlib.sha256
            node.func.attr = 'sha256'
        # Check for md5() style direct calls
        elif isinstance(node.func, ast.Name) and node.func.id in self.weak_hashes:
            self.used_hashlib = True
            node.func.id = 'sha256'
            
        return self.generic_visit(node)
