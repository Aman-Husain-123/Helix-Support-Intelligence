import argparse
import sys
import os
import json
from typing import List
from analyzer import Analyzer
from report import Report

def validate_paths(paths: List[str]) -> List[str]:
    """
    Validates that the provided paths exist.
    """
    valid_paths: List[str] = []
    for path in paths:
        if not os.path.exists(path):
            print(f"Error: The path '{path}' does not exist.", file=sys.stderr)
            sys.exit(1)
        valid_paths.append(os.path.abspath(path))
    return valid_paths

def main() -> None:
    parser = argparse.ArgumentParser(
        description="CodeGuard: A static code analyzer for Python.",
        usage="%(prog)s [options] <path>..."
    )
    
    parser.add_argument(
        'paths',
        nargs='+',
        help="One or more Python file paths or directories to analyze."
    )
    
    parser.add_argument(
        '-o', '--output',
        dest='output',
        help="Path to save the analysis report (json or txt)."
    )

    parser.add_argument(
        '--json',
        action='store_true',
        help="Output results in JSON format to stdout."
    )
    
    args = parser.parse_args()
    
    # Validate inputs
    valid_paths: List[str] = validate_paths(args.paths)
    
    # Initialize Analyzer
    analyzer = Analyzer()
    
    # Run analysis
    try:
        report: Report = analyzer.run(valid_paths, quiet=args.json)
        
        if args.json:
            data = {
                "summary": {
                    "total_files": report.total_files,
                    "total_issues": len(report.findings),
                    "errors": len(report.errors)
                },
                "findings": [f.to_dict() for f in report.findings],
                "errors": report.errors
            }
            print(json.dumps(data))
        else:
            # Always output to console
            report.print_summary()
            
            # Handle file export if requested
            if args.output:
                if args.output.endswith('.json'):
                    report.export_json(args.output)
                else:
                    report.export_txt(args.output)
            
    except Exception as e:
        if args.json:
            print(json.dumps({"error": str(e)}))
        else:
            print(f"An unexpected error occurred during execution: {e}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()
