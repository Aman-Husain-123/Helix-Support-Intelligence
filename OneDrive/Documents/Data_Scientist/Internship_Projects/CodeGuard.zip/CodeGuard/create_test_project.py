#!/usr/bin/env python3
"""
Create a test ML project with security issues for demonstration
"""
import os
import zipfile
from pathlib import Path

def create_test_project():
    """Create a sample ML project with various security issues"""
    
    # Create project structure
    project_name = "ml_security_demo"
    project_path = Path(project_name)
    
    # Remove existing project if it exists
    if project_path.exists():
        import shutil
        shutil.rmtree(project_path)
    
    # Create directories
    dirs = [
        "src/models",
        "src/data",
        "src/utils",
        "config",
        "tests",
        "notebooks"
    ]
    
    for dir_path in dirs:
        (project_path / dir_path).mkdir(parents=True, exist_ok=True)
    
    # Create files with security issues
    files = {
        "src/models/classifier.py": '''
import pickle
import joblib
import torch
import hashlib
import os

# SECURITY ISSUE: Hardcoded credentials
API_KEY = "sk_live_ml_model_12345"
MODEL_SECRET = "super_secret_model_key"
DATABASE_URL = "postgresql://admin:password123@localhost/mldb"

class MLClassifier:
    def __init__(self):
        self.model = None
        self.api_key = API_KEY
    
    def load_model(self, model_path):
        # SECURITY ISSUE: Insecure model loading
        with open(model_path, 'rb') as f:
            self.model = pickle.load(f)  # Dangerous deserialization
        return self.model
    
    def load_torch_model(self, model_url):
        # SECURITY ISSUE: Loading untrusted models
        self.model = torch.load(model_url)  # Should use weights_only=True
        return self.model
    
    def hash_data(self, data):
        # SECURITY ISSUE: Weak hashing
        return hashlib.md5(data.encode()).hexdigest()
    
    def execute_preprocessing(self, user_code):
        # SECURITY ISSUE: Code injection
        return eval(user_code)  # Extremely dangerous
    
    def authenticate(self, username, password):
        # SECURITY ISSUE: SQL injection vulnerability
        query = f"SELECT * FROM users WHERE username='{username}' AND password='{password}'"
        return query
''',
        
        "src/data/processor.py": '''
import subprocess
import os
import pickle
import pandas as pd

# SECURITY ISSUES: More hardcoded secrets
AWS_ACCESS_KEY = "AKIAIOSFODNN7EXAMPLE"
AWS_SECRET_KEY = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"
MONGODB_URI = "mongodb://admin:secret123@cluster.mongodb.net/ml_data"

class DataProcessor:
    def __init__(self):
        self.aws_key = AWS_ACCESS_KEY
        self.mongo_uri = MONGODB_URI
    
    def run_system_command(self, command):
        # SECURITY ISSUE: Command injection
        result = subprocess.run(command, shell=True, capture_output=True)
        return result.stdout
    
    def load_cached_data(self, cache_file):
        # SECURITY ISSUE: Insecure deserialization
        return pickle.load(open(cache_file, 'rb'))
    
    def process_user_input(self, user_data):
        # SECURITY ISSUE: Dynamic execution
        exec(user_data)  # Another dangerous function
    
    def validate_file_path(self, filepath):
        # SECURITY ISSUE: Path traversal
        with open(f"/data/{filepath}", 'r') as f:
            return f.read()
    
    def generate_hash(self, content):
        # SECURITY ISSUE: Weak cryptography
        import hashlib
        return hashlib.sha1(content.encode()).hexdigest()
''',
        
        "src/utils/helpers.py": '''
import requests
import json
import hashlib

# SECURITY ISSUES: API keys and tokens
OPENAI_API_KEY = "sk-1234567890abcdef"
HUGGINGFACE_TOKEN = "hf_1234567890abcdef"
WANDB_API_KEY = "local-1234567890abcdef"

def download_model(url, api_key=OPENAI_API_KEY):
    """Download model from external source"""
    headers = {"Authorization": f"Bearer {api_key}"}
    response = requests.get(url, headers=headers)
    
    # SECURITY ISSUE: Insecure temp file handling
    with open("/tmp/model.pkl", "wb") as f:
        f.write(response.content)
    
    # SECURITY ISSUE: Loading without validation
    import pickle
    return pickle.load(open("/tmp/model.pkl", "rb"))

def hash_password(password):
    # SECURITY ISSUE: Weak hashing for passwords
    return hashlib.md5(password.encode()).hexdigest()

def execute_notebook_cell(cell_code):
    # SECURITY ISSUE: Executing arbitrary code
    return eval(cell_code)
''',
        
        "config/settings.py": '''
import os

# SECURITY ISSUES: Configuration with secrets
class Config:
    # Database credentials
    DB_HOST = "localhost"
    DB_USER = "admin"
    DB_PASSWORD = "admin123"  # Hardcoded password
    DB_NAME = "ml_production"
    
    # API Keys
    OPENAI_KEY = "sk-proj-1234567890"
    ANTHROPIC_KEY = "sk-ant-1234567890"
    COHERE_KEY = "co-1234567890"
    
    # JWT Secret
    JWT_SECRET_KEY = "my-super-secret-jwt-key-123"
    
    # Redis
    REDIS_URL = "redis://admin:password@localhost:6379/0"
    
    # Model paths
    MODEL_DIR = "/models"
    CHECKPOINT_DIR = "/checkpoints"
    
    @staticmethod
    def get_db_connection():
        # SECURITY ISSUE: SQL injection potential
        connection_string = f"postgresql://{Config.DB_USER}:{Config.DB_PASSWORD}@{Config.DB_HOST}/{Config.DB_NAME}"
        return connection_string
''',
        
        "tests/test_security.py": '''
import unittest
import hashlib
from src.models.classifier import MLClassifier
from src.data.processor import DataProcessor

# SECURITY ISSUE: Test credentials
TEST_API_KEY = "test_api_key_12345"
TEST_SECRET = "test_secret_password"

class TestSecurity(unittest.TestCase):
    def setUp(self):
        self.classifier = MLClassifier()
        self.processor = DataProcessor()
        self.test_key = TEST_API_KEY
    
    def test_model_loading(self):
        # This test demonstrates insecure practices
        model_path = "/tmp/test_model.pkl"
        
        # SECURITY ISSUE: Creating pickle file for testing
        import pickle
        test_data = {"model": "test"}
        with open(model_path, "wb") as f:
            pickle.dump(test_data, f)
        
        # Loading without validation
        result = self.classifier.load_model(model_path)
        self.assertIsNotNone(result)
    
    def test_hash_function(self):
        # SECURITY ISSUE: Testing weak hash
        password = "test_password"
        hashed = hashlib.md5(password.encode()).hexdigest()
        self.assertEqual(len(hashed), 32)
    
    def test_command_execution(self):
        # SECURITY ISSUE: Testing command injection
        command = "echo 'test'"
        result = self.processor.run_system_command(command)
        self.assertIsNotNone(result)

if __name__ == "__main__":
    unittest.main()
''',
        
        "notebooks/data_analysis.py": '''
# Jupyter notebook converted to .py for analysis
import pandas as pd
import numpy as np
import pickle
import os

# SECURITY ISSUES: Notebook-style security problems
KAGGLE_KEY = "kaggle_api_key_12345"
DATASET_TOKEN = "dataset_access_token_xyz"

def load_dataset(dataset_path):
    """Load dataset with potential security issues"""
    
    # SECURITY ISSUE: Path traversal in notebooks
    full_path = f"/datasets/{dataset_path}"
    
    # SECURITY ISSUE: Pickle loading without validation
    if dataset_path.endswith('.pkl'):
        with open(full_path, 'rb') as f:
            return pickle.load(f)
    
    return pd.read_csv(full_path)

def run_analysis_code(analysis_code):
    """Execute user-provided analysis code"""
    # SECURITY ISSUE: Code execution in notebooks
    exec(analysis_code)

def download_external_data(url):
    """Download data from external source"""
    import requests
    
    # SECURITY ISSUE: Hardcoded credentials for external APIs
    headers = {
        "Authorization": f"Bearer {KAGGLE_KEY}",
        "X-API-Token": DATASET_TOKEN
    }
    
    response = requests.get(url, headers=headers)
    
    # SECURITY ISSUE: Saving to predictable location
    with open("/tmp/downloaded_data.csv", "w") as f:
        f.write(response.text)
    
    return "/tmp/downloaded_data.csv"

# SECURITY ISSUE: Global variables with secrets
MLFLOW_TRACKING_URI = "http://admin:password@localhost:5000"
TENSORBOARD_LOG_DIR = "/logs/tensorboard"

print("Data analysis notebook loaded with security vulnerabilities for testing")
''',
        
        "requirements.txt": '''
torch>=1.9.0
tensorflow>=2.8.0
scikit-learn>=1.0.0
pandas>=1.3.0
numpy>=1.21.0
joblib>=1.1.0
pickle5>=0.0.11
requests>=2.25.0
flask>=2.0.0
sqlalchemy>=1.4.0
redis>=4.0.0
pymongo>=4.0.0
''',
        
        "README.md": '''
# ML Security Demo Project

This is a demonstration project containing various security vulnerabilities commonly found in ML/Data Science projects.

## Security Issues Included:

1. **Hardcoded Credentials**: API keys, passwords, and tokens in source code
2. **Insecure Deserialization**: Using pickle.load() without validation
3. **Code Injection**: eval() and exec() with user input
4. **Command Injection**: subprocess with shell=True
5. **Weak Cryptography**: MD5 and SHA1 for sensitive data
6. **Path Traversal**: Unsafe file path handling
7. **SQL Injection**: String formatting in queries
8. **Insecure Model Loading**: Loading ML models without validation

## Files with Issues:

- `src/models/classifier.py`: ML model security issues
- `src/data/processor.py`: Data processing vulnerabilities
- `src/utils/helpers.py`: Utility function security flaws
- `config/settings.py`: Configuration security problems
- `tests/test_security.py`: Test code with security issues
- `notebooks/data_analysis.py`: Notebook-style vulnerabilities

This project is designed to test security analysis tools and should NOT be used in production.
'''
    }
    
    # Write all files
    for file_path, content in files.items():
        full_path = project_path / file_path
        full_path.parent.mkdir(parents=True, exist_ok=True)
        with open(full_path, 'w', encoding='utf-8') as f:
            f.write(content.strip())
    
    # Create ZIP file
    zip_path = f"{project_name}.zip"
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(project_path):
            for file in files:
                file_path = os.path.join(root, file)
                arcname = os.path.relpath(file_path, project_path.parent)
                zipf.write(file_path, arcname)
    
    print(f"✅ Created test project: {zip_path}")
    print(f"📊 Project contains {len(files)} files with various security issues")
    print(f"🔍 Upload this ZIP file to test the project analyzer")
    
    # Cleanup
    import shutil
    shutil.rmtree(project_path)
    
    return zip_path

if __name__ == "__main__":
    create_test_project()