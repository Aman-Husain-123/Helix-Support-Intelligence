import os
import sys
import json
import uuid
import tempfile
import ast
import zipfile
import threading
from flask import Flask, request, jsonify, render_template, send_file
from flask_cors import CORS
from datetime import datetime
from werkzeug.utils import secure_filename
from project_analyzer import ProjectAnalyzer
import time

# Initialize Flask App
app = Flask(__name__, template_folder='templates', static_folder='static')
CORS(app)

# Configuration
app.config['MAX_CONTENT_LENGTH'] = 100 * 1024 * 1024  # 100MB max upload
app.config['UPLOAD_FOLDER'] = tempfile.gettempdir()

# Global variables for progress tracking
analysis_progress = {}
analysis_results = {}

# Fast analyzer for single files (existing)
class FastAnalyzer:
    def __init__(self):
        self.dangerous_funcs = {'eval', 'exec'}
        self.secret_keywords = {'password', 'secret', 'api_key', 'token', 'key', 'db', 'url', 'conn', 'cred'}
        self.weak_hashes = {'md5', 'sha1'}
    
    def analyze_code(self, code):
        findings = []
        errors = []
        
        try:
            if len(code) > 100000:
                errors.append({
                    'file': 'input',
                    'type': 'SizeError',
                    'message': 'Code too large for analysis (max 100KB)'
                })
                return self._format_result(findings, errors)
            
            tree = ast.parse(code)
            node_count = 0
            max_nodes = 5000
            
            for node in ast.walk(tree):
                node_count += 1
                if node_count > max_nodes:
                    break
                
                if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
                    if node.func.id in self.dangerous_funcs:
                        findings.append({
                            'line': node.lineno,
                            'column': getattr(node, 'col_offset', 0),
                            'severity': 'CRITICAL',
                            'message': f"Dangerous function '{node.func.id}()' detected",
                            'remediation': f"Replace {node.func.id}() with safer alternatives like ast.literal_eval() for data parsing",
                            'rule_name': 'DangerousFunctionsRule'
                        })
                
                if isinstance(node, ast.Assign) and isinstance(node.value, ast.Constant):
                    if isinstance(node.value.value, str) and len(node.value.value) > 3:
                        for target in node.targets:
                            if isinstance(target, ast.Name):
                                var_name = target.id.lower()
                                if any(keyword in var_name for keyword in self.secret_keywords):
                                    findings.append({
                                        'line': node.lineno,
                                        'column': getattr(node, 'col_offset', 0),
                                        'severity': 'HIGH',
                                        'message': f"Hardcoded credential detected in variable '{target.id}'",
                                        'remediation': f"Move '{target.id}' to environment variables: {target.id} = os.getenv('{target.id.upper()}')",
                                        'rule_name': 'HardcodedCredentialsRule'
                                    })
                
                if isinstance(node, ast.Call):
                    func_name = ""
                    if isinstance(node.func, ast.Attribute) and node.func.attr in self.weak_hashes:
                        func_name = node.func.attr
                    elif isinstance(node.func, ast.Name) and node.func.id in self.weak_hashes:
                        func_name = node.func.id
                    
                    if func_name:
                        findings.append({
                            'line': node.lineno,
                            'column': getattr(node, 'col_offset', 0),
                            'severity': 'MEDIUM',
                            'message': f"Weak hashing algorithm '{func_name}' detected",
                            'remediation': f"Replace {func_name} with SHA-256: hashlib.sha256()",
                            'rule_name': 'WeakHashingRule'
                        })
        
        except SyntaxError as e:
            errors.append({
                'file': 'input',
                'type': 'SyntaxError',
                'message': f"Syntax error: {str(e)}"
            })
        except Exception as e:
            errors.append({
                'file': 'input',
                'type': 'AnalysisError',
                'message': f"Analysis error: {str(e)}"
            })
        
        return self._format_result(findings, errors)
    
    def _format_result(self, findings, errors):
        return {
            'findings': findings,
            'errors': errors,
            'summary': {
                'total_files': 1,
                'total_issues': len(findings),
                'errors': len(errors)
            }
        }

# Initialize analyzers
fast_analyzer = FastAnalyzer()
project_analyzer = ProjectAnalyzer()

def progress_callback(analysis_id, message, progress):
    """Callback for progress updates"""
    analysis_progress[analysis_id] = {
        'message': message,
        'progress': progress,
        'timestamp': datetime.now().isoformat()
    }

@app.route('/')
def index():
    """Serves the main UI."""
    return render_template('index.html')

@app.route('/api/analyze', methods=['POST'])
def analyze_code():
    """Fast single-file analysis endpoint."""
    try:
        data = request.json
        if not data:
            return jsonify({"error": "Invalid JSON payload"}), 400
            
        code = data.get('code', '').strip()
        filename = data.get('filename', 'neural_snippet.py')
        
        if not code:
            return jsonify({"error": "Source code is required"}), 400

        print(f"🔍 Fast analyzing: {filename} ({len(code)} chars)")
        
        import time
        start_time = time.time()
        result = fast_analyzer.analyze_code(code)
        analysis_time = time.time() - start_time
        
        response = {
            "id": str(uuid.uuid4()),
            "summary": result['summary'],
            "findings": result['findings'],
            "errors": result['errors'],
            "timestamp": datetime.now().isoformat(),
            "analysis_time": f"{analysis_time:.3f}s"
        }
        
        print(f"✅ Analysis completed in {analysis_time:.3f}s - {len(result['findings'])} findings")
        return jsonify(response)

    except Exception as e:
        print(f"❌ API error: {e}")
        return jsonify({
            "error": "Analysis failed",
            "message": str(e)[:200]
        }), 500

@app.route('/api/upload-project', methods=['POST'])
def upload_project():
    """Handle project upload and start analysis"""
    try:
        if 'project' not in request.files:
            return jsonify({"error": "No project file uploaded"}), 400
        
        file = request.files['project']
        if file.filename == '':
            return jsonify({"error": "No file selected"}), 400
        
        if not file.filename.endswith('.zip'):
            return jsonify({"error": "Only ZIP files are supported"}), 400
        
        # Save uploaded file
        filename = secure_filename(file.filename)
        analysis_id = str(uuid.uuid4())
        upload_path = os.path.join(app.config['UPLOAD_FOLDER'], f"{analysis_id}_{filename}")
        file.save(upload_path)
        
        # Start analysis in background thread
        def analyze_project_async():
            try:
                # Set up progress callback
                project_analyzer.set_progress_callback(
                    lambda msg, prog: progress_callback(analysis_id, msg, prog)
                )
                
                # Extract project
                progress_callback(analysis_id, "Extracting project...", 5)
                extract_path = os.path.join(app.config['UPLOAD_FOLDER'], f"extracted_{analysis_id}")
                project_analyzer.extract_project(upload_path, extract_path)
                
                # Analyze project
                progress_callback(analysis_id, "Starting analysis...", 10)
                result = project_analyzer.analyze_project_chunked(extract_path)
                
                # Store results
                analysis_results[analysis_id] = result
                progress_callback(analysis_id, "Analysis complete!", 100)
                
                # Cleanup
                os.remove(upload_path)
                
            except Exception as e:
                analysis_results[analysis_id] = {
                    'error': str(e),
                    'summary': {'total_files': 0, 'total_issues': 0, 'errors': 1}
                }
                progress_callback(analysis_id, f"Analysis failed: {str(e)}", 100)
        
        # Start background analysis
        thread = threading.Thread(target=analyze_project_async)
        thread.daemon = True
        thread.start()
        
        return jsonify({
            "analysis_id": analysis_id,
            "message": "Project upload successful. Analysis started.",
            "status": "processing"
        })
        
    except Exception as e:
        print(f"❌ Upload error: {e}")
        return jsonify({
            "error": "Upload failed",
            "message": str(e)
        }), 500

@app.route('/api/analysis-progress/<analysis_id>', methods=['GET'])
def get_analysis_progress(analysis_id):
    """Get analysis progress"""
    if analysis_id in analysis_progress:
        progress_info = analysis_progress[analysis_id]
        
        # Check if analysis is complete
        if analysis_id in analysis_results:
            progress_info['status'] = 'complete'
            progress_info['has_results'] = True
        else:
            progress_info['status'] = 'processing'
            progress_info['has_results'] = False
        
        return jsonify(progress_info)
    else:
        return jsonify({"error": "Analysis not found"}), 404

@app.route('/api/analysis-results/<analysis_id>', methods=['GET'])
def get_analysis_results(analysis_id):
    """Get analysis results"""
    if analysis_id in analysis_results:
        return jsonify(analysis_results[analysis_id])
    else:
        return jsonify({"error": "Results not found"}), 404

@app.route('/api/generate-fixed-file', methods=['POST'])
def generate_fixed_file():
    """Generate fixed version of a file"""
    try:
        data = request.json
        analysis_id = data.get('analysis_id')
        file_path = data.get('file_path')
        
        if not analysis_id or not file_path:
            return jsonify({"error": "Missing analysis_id or file_path"}), 400
        
        if analysis_id not in analysis_results:
            return jsonify({"error": "Analysis not found"}), 404
        
        results = analysis_results[analysis_id]
        
        # Find the file in results
        file_result = None
        for file_data in results.get('files', []):
            if file_data['file'] == file_path:
                file_result = file_data
                break
        
        if not file_result:
            return jsonify({"error": "File not found in analysis results"}), 404
        
        # Generate fixed file (mock implementation)
        # In a real implementation, you would use the project_analyzer.generate_fixed_file method
        fixed_content = f"""# SECURITY-FIXED VERSION OF: {file_path}
# Generated on: {datetime.now().isoformat()}
# 
# This file has been automatically fixed based on security analysis.
# Please review all changes before using in production.

# Original issues found: {len(file_result['findings'])}
# Suggestions applied: {len(file_result['suggestions'])}

# TODO: Implement actual file fixing logic here
# This would read the original file and apply the security fixes
"""
        
        return jsonify({
            "fixed_content": fixed_content,
            "original_issues": len(file_result['findings']),
            "timestamp": datetime.now().isoformat()
        })
        
    except Exception as e:
        return jsonify({
            "error": "Failed to generate fixed file",
            "message": str(e)
        }), 500

@app.route('/api/fix', methods=['POST'])
def fix_code():
    """AI-powered secure code generation for single files."""
    try:
        data = request.json
        code = data.get('code', '')
        
        print(f"🔧 Generating secure code...")
        
        fixed_code = code
        
        # Fix dangerous functions
        fixed_code = fixed_code.replace('eval(', 'ast.literal_eval(')
        fixed_code = fixed_code.replace('exec(', '# SECURITY: exec() removed - use safer alternatives')
        
        # Fix weak hashing
        fixed_code = fixed_code.replace('hashlib.md5(', 'hashlib.sha256(')
        fixed_code = fixed_code.replace('hashlib.sha1(', 'hashlib.sha256(')
        fixed_code = fixed_code.replace('.md5()', '.sha256()')
        fixed_code = fixed_code.replace('.sha1()', '.sha256()')
        
        # Fix hardcoded credentials
        lines = fixed_code.split('\n')
        imports_added = False
        
        for i, line in enumerate(lines):
            if '=' in line and any(keyword in line.lower() for keyword in ['password', 'secret', 'key', 'token', 'api']):
                if ('"' in line or "'" in line) and not line.strip().startswith('#'):
                    if not imports_added and 'import os' not in fixed_code:
                        lines.insert(0, 'import os')
                        imports_added = True
                        i += 1
                    
                    var_name = line.split('=')[0].strip()
                    lines[i] = f"{var_name} = os.getenv('{var_name.upper()}', 'default_value')  # SECURITY: Moved to environment variable"
        
        fixed_code = '\n'.join(lines)
        
        print("✅ Secure code generated")
        return jsonify({
            "fixedCode": fixed_code,
            "timestamp": datetime.now().isoformat()
        })
        
    except Exception as e:
        print(f"❌ Fix error: {e}")
        return jsonify({
            "fixedCode": f"# SECURITY FIX FAILED: {str(e)}\n# Original code preserved below:\n\n{code}",
            "error": str(e)
        })

@app.route('/api/status', methods=['GET'])
def get_status():
    """System health check."""
    return jsonify({
        "status": "online",
        "version": "3.0.0_PROJECT_ANALYZER",
        "engine": "advanced_project_analyzer",
        "features": ["single_file_analysis", "project_upload", "chunked_processing", "ml_security"],
        "performance": "optimized",
        "timestamp": datetime.now().isoformat()
    })

@app.errorhandler(404)
def not_found(error):
    return jsonify({"error": "Endpoint not found"}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({"error": "Internal server error"}), 500

@app.errorhandler(413)
def too_large(error):
    return jsonify({"error": "File too large (max 100MB)"}), 413

if __name__ == '__main__':
    print(f"\n{'='*70}")
    print("🛡️  CODEGUARD AI - ADVANCED PROJECT ANALYZER")
    print(f"{'='*70}")
    print(f"🚀 Neural Core Status: ONLINE")
    print(f"🌐 Web Interface: http://localhost:5001")
    print(f"⚡ Performance Mode: OPTIMIZED FOR LARGE PROJECTS")
    print(f"🔧 Security Engine: Advanced + ML Security")
    print(f"📦 Project Support: ZIP Upload + Chunked Processing")
    print(f"💾 Database: Local Mode (No Dependencies)")
    print(f"📊 Max Upload Size: 100MB")
    print(f"{'='*70}\n")
    
    try:
        app.run(host='0.0.0.0', port=5001, debug=False, threaded=True)
    except KeyboardInterrupt:
        print("\n🛑 CodeGuard AI shutdown initiated by user")
    except Exception as e:
        print(f"\n❌ Server startup failed: {e}")
        sys.exit(1)
