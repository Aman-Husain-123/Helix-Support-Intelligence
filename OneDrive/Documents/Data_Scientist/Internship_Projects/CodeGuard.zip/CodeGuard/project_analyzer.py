#!/usr/bin/env python3
"""
Advanced Project Analyzer for Complex Python/ML Projects
Handles directory uploads, chunked processing, and comprehensive analysis
"""
import os
import ast
import json
import uuid
import zipfile
import tempfile
import threading
from pathlib import Path
from typing import List, Dict, Any, Generator, Optional
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

class ProjectAnalyzer:
    """
    Advanced analyzer for complex Python projects with chunked processing
    """
    
    def __init__(self, max_file_size: int = 1024 * 1024, chunk_size: int = 50):
        self.max_file_size = max_file_size  # 1MB per file
        self.chunk_size = chunk_size  # Files per chunk
        self.dangerous_funcs = {'eval', 'exec', 'compile', '__import__'}
        self.secret_keywords = {
            'password', 'secret', 'api_key', 'token', 'key', 'db', 'url', 
            'conn', 'cred', 'auth', 'bearer', 'jwt', 'session', 'cookie'
        }
        self.weak_hashes = {'md5', 'sha1'}
        self.ml_security_patterns = {
            'pickle.load', 'pickle.loads', 'joblib.load', 'torch.load',
            'tensorflow.saved_model.load', 'keras.models.load_model'
        }
        self.analysis_results = {}
        self.progress_callback = None
        
    def set_progress_callback(self, callback):
        """Set callback function for progress updates"""
        self.progress_callback = callback
        
    def extract_project(self, zip_path: str, extract_to: str) -> str:
        """Extract uploaded project zip file"""
        try:
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                # Security check: prevent zip bombs and path traversal
                for member in zip_ref.namelist():
                    if member.startswith('/') or '..' in member:
                        raise ValueError(f"Unsafe path in zip: {member}")
                    if len(member) > 255:
                        raise ValueError(f"Path too long: {member}")
                
                zip_ref.extractall(extract_to)
                return extract_to
        except Exception as e:
            raise Exception(f"Failed to extract project: {str(e)}")
    
    def discover_python_files(self, project_path: str) -> List[Dict[str, Any]]:
        """Discover all Python files in the project with metadata"""
        python_files = []
        
        # Common directories to skip for performance
        skip_dirs = {
            '__pycache__', '.git', '.svn', 'node_modules', '.venv', 'venv',
            'env', '.env', 'build', 'dist', '.pytest_cache', '.mypy_cache',
            '.tox', 'htmlcov', '.coverage', 'logs', 'log'
        }
        
        # ML-specific directories to skip
        ml_skip_dirs = {
            'data', 'datasets', 'models', 'checkpoints', 'weights',
            'tensorboard', 'wandb', 'mlruns', '.dvc'
        }
        
        skip_dirs.update(ml_skip_dirs)
        
        for root, dirs, files in os.walk(project_path):
            # Remove skip directories from traversal
            dirs[:] = [d for d in dirs if d not in skip_dirs]
            
            for file in files:
                if file.endswith('.py'):
                    file_path = os.path.join(root, file)
                    try:
                        stat = os.stat(file_path)
                        relative_path = os.path.relpath(file_path, project_path)
                        
                        # Skip files that are too large
                        if stat.st_size > self.max_file_size:
                            continue
                            
                        python_files.append({
                            'path': file_path,
                            'relative_path': relative_path,
                            'size': stat.st_size,
                            'modified': datetime.fromtimestamp(stat.st_mtime),
                            'is_test': self._is_test_file(file),
                            'is_config': self._is_config_file(file),
                            'category': self._categorize_file(relative_path)
                        })
                    except (OSError, IOError):
                        continue
        
        return sorted(python_files, key=lambda x: x['size'])
    
    def _is_test_file(self, filename: str) -> bool:
        """Check if file is a test file"""
        test_patterns = ['test_', '_test.py', 'tests.py', 'conftest.py']
        return any(pattern in filename.lower() for pattern in test_patterns)
    
    def _is_config_file(self, filename: str) -> bool:
        """Check if file is a configuration file"""
        config_patterns = ['config', 'settings', 'setup.py', '__init__.py']
        return any(pattern in filename.lower() for pattern in config_patterns)
    
    def _categorize_file(self, relative_path: str) -> str:
        """Categorize file based on path and content"""
        path_lower = relative_path.lower()
        
        if 'model' in path_lower or 'ml' in path_lower or 'ai' in path_lower:
            return 'ml_model'
        elif 'data' in path_lower or 'preprocess' in path_lower:
            return 'data_processing'
        elif 'api' in path_lower or 'server' in path_lower or 'web' in path_lower:
            return 'web_api'
        elif 'test' in path_lower:
            return 'test'
        elif 'config' in path_lower or 'setting' in path_lower:
            return 'configuration'
        elif 'util' in path_lower or 'helper' in path_lower:
            return 'utility'
        else:
            return 'core'
    
    def create_file_chunks(self, files: List[Dict[str, Any]]) -> Generator[List[Dict[str, Any]], None, None]:
        """Create chunks of files for processing"""
        for i in range(0, len(files), self.chunk_size):
            yield files[i:i + self.chunk_size]
    
    def analyze_file(self, file_info: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze a single Python file"""
        file_path = file_info['path']
        relative_path = file_info['relative_path']
        
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            # Skip empty files
            if not content.strip():
                return {
                    'file': relative_path,
                    'findings': [],
                    'errors': [],
                    'metrics': {'lines': 0, 'complexity': 0},
                    'suggestions': []
                }
            
            # Parse AST
            try:
                tree = ast.parse(content)
            except SyntaxError as e:
                return {
                    'file': relative_path,
                    'findings': [],
                    'errors': [{
                        'type': 'SyntaxError',
                        'message': str(e),
                        'line': getattr(e, 'lineno', 0)
                    }],
                    'metrics': {'lines': len(content.split('\n')), 'complexity': 0},
                    'suggestions': ['Fix syntax errors before security analysis']
                }
            
            # Analyze the AST
            findings = []
            metrics = self._calculate_metrics(content, tree)
            suggestions = []
            
            # Security analysis
            for node in ast.walk(tree):
                findings.extend(self._check_security_issues(node, file_info))
            
            # ML-specific analysis
            if file_info['category'] == 'ml_model':
                findings.extend(self._check_ml_security(content, tree))
                suggestions.extend(self._get_ml_suggestions(content))
            
            # Generate improvement suggestions
            suggestions.extend(self._generate_suggestions(findings, file_info))
            
            return {
                'file': relative_path,
                'findings': findings,
                'errors': [],
                'metrics': metrics,
                'suggestions': list(set(suggestions))  # Remove duplicates
            }
            
        except Exception as e:
            return {
                'file': relative_path,
                'findings': [],
                'errors': [{
                    'type': 'AnalysisError',
                    'message': str(e),
                    'line': 0
                }],
                'metrics': {'lines': 0, 'complexity': 0},
                'suggestions': []
            }
    
    def _check_security_issues(self, node: ast.AST, file_info: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Check for security issues in AST node"""
        findings = []
        
        # Dangerous functions
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
            if node.func.id in self.dangerous_funcs:
                findings.append({
                    'line': node.lineno,
                    'column': getattr(node, 'col_offset', 0),
                    'severity': 'CRITICAL',
                    'category': 'dangerous_function',
                    'message': f"Dangerous function '{node.func.id}()' detected",
                    'remediation': self._get_function_remediation(node.func.id),
                    'rule_name': 'DangerousFunctionsRule'
                })
        
        # Hardcoded credentials
        if isinstance(node, ast.Assign) and isinstance(node.value, ast.Constant):
            if isinstance(node.value.value, str) and len(node.value.value) > 5:
                for target in node.targets:
                    if isinstance(target, ast.Name):
                        var_name = target.id.lower()
                        if any(keyword in var_name for keyword in self.secret_keywords):
                            findings.append({
                                'line': node.lineno,
                                'column': getattr(node, 'col_offset', 0),
                                'severity': 'HIGH',
                                'category': 'hardcoded_credential',
                                'message': f"Hardcoded credential in variable '{target.id}'",
                                'remediation': f"Move to environment variable: {target.id} = os.getenv('{target.id.upper()}')",
                                'rule_name': 'HardcodedCredentialsRule'
                            })
        
        # Weak hashing
        if isinstance(node, ast.Call):
            func_name = ""
            if isinstance(node.func, ast.Attribute) and node.func.attr in self.weak_hashes:
                func_name = node.func.attr
            elif isinstance(node.func, ast.Name) and node.func.id in self.weak_hashes:
                func_name = node.func.id
            
            if func_name:
                findings.append({
                    'line': node.lineno,
                    'column': getattr(node, 'col_offset', 0),
                    'severity': 'MEDIUM',
                    'category': 'weak_crypto',
                    'message': f"Weak hashing algorithm '{func_name}' detected",
                    'remediation': f"Replace with SHA-256: hashlib.sha256()",
                    'rule_name': 'WeakHashingRule'
                })
        
        return findings
    
    def _check_ml_security(self, content: str, tree: ast.Module) -> List[Dict[str, Any]]:
        """Check for ML-specific security issues"""
        findings = []
        
        # Check for insecure model loading
        for pattern in self.ml_security_patterns:
            if pattern in content:
                # Find the line number
                lines = content.split('\n')
                for i, line in enumerate(lines, 1):
                    if pattern in line:
                        findings.append({
                            'line': i,
                            'column': 0,
                            'severity': 'HIGH',
                            'category': 'ml_security',
                            'message': f"Insecure model loading detected: {pattern}",
                            'remediation': "Validate model source and use secure loading methods",
                            'rule_name': 'MLSecurityRule'
                        })
                        break
        
        return findings
    
    def _calculate_metrics(self, content: str, tree: ast.Module) -> Dict[str, Any]:
        """Calculate code metrics"""
        lines = len(content.split('\n'))
        
        # Calculate cyclomatic complexity (simplified)
        complexity = 1  # Base complexity
        for node in ast.walk(tree):
            if isinstance(node, (ast.If, ast.While, ast.For, ast.Try, ast.With)):
                complexity += 1
            elif isinstance(node, ast.BoolOp):
                complexity += len(node.values) - 1
        
        return {
            'lines': lines,
            'complexity': complexity,
            'functions': len([n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef)]),
            'classes': len([n for n in ast.walk(tree) if isinstance(n, ast.ClassDef)]),
            'imports': len([n for n in ast.walk(tree) if isinstance(n, (ast.Import, ast.ImportFrom))])
        }
    
    def _get_function_remediation(self, func_name: str) -> str:
        """Get specific remediation for dangerous functions"""
        remediations = {
            'eval': "Use ast.literal_eval() for safe evaluation of literals",
            'exec': "Avoid dynamic code execution. Use structured approaches instead",
            'compile': "Avoid compiling untrusted code. Use static analysis instead",
            '__import__': "Use importlib.import_module() with proper validation"
        }
        return remediations.get(func_name, "Replace with safer alternative")
    
    def _generate_suggestions(self, findings: List[Dict[str, Any]], file_info: Dict[str, Any]) -> List[str]:
        """Generate improvement suggestions based on findings"""
        suggestions = []
        
        if findings:
            severity_counts = {}
            for finding in findings:
                severity = finding['severity']
                severity_counts[severity] = severity_counts.get(severity, 0) + 1
            
            if severity_counts.get('CRITICAL', 0) > 0:
                suggestions.append("🚨 Critical security issues found - immediate attention required")
            
            if severity_counts.get('HIGH', 0) > 2:
                suggestions.append("🔒 Consider implementing a security review process")
            
            # Category-specific suggestions
            categories = [f['category'] for f in findings]
            if 'hardcoded_credential' in categories:
                suggestions.append("🔑 Implement environment-based configuration management")
            
            if 'dangerous_function' in categories:
                suggestions.append("⚠️ Review dynamic code execution patterns")
        
        # File-specific suggestions
        if file_info['category'] == 'ml_model':
            suggestions.append("🤖 Consider implementing model validation and sandboxing")
        
        if file_info['size'] > 500000:  # Large file
            suggestions.append("📦 Consider breaking down large files into smaller modules")
        
        return suggestions
    
    def _get_ml_suggestions(self, content: str) -> List[str]:
        """Get ML-specific suggestions"""
        suggestions = []
        
        if 'pickle' in content:
            suggestions.append("🔒 Consider using safer serialization formats like joblib or custom JSON")
        
        if 'torch.load' in content:
            suggestions.append("🛡️ Use torch.load with map_location and weights_only=True for security")
        
        if 'tensorflow' in content and 'saved_model' in content:
            suggestions.append("🔐 Validate TensorFlow model signatures before loading")
        
        return suggestions
    
    def analyze_project_chunked(self, project_path: str) -> Dict[str, Any]:
        """Analyze entire project using chunked processing"""
        start_time = time.time()
        
        # Discover all Python files
        if self.progress_callback:
            self.progress_callback("Discovering Python files...", 0)
        
        python_files = self.discover_python_files(project_path)
        total_files = len(python_files)
        
        if total_files == 0:
            return {
                'summary': {
                    'total_files': 0,
                    'total_issues': 0,
                    'errors': 0,
                    'analysis_time': time.time() - start_time
                },
                'files': [],
                'project_metrics': {},
                'recommendations': ["No Python files found in the project"]
            }
        
        # Process files in chunks
        all_results = []
        processed_files = 0
        
        chunks = list(self.create_file_chunks(python_files))
        
        for chunk_idx, chunk in enumerate(chunks):
            if self.progress_callback:
                progress = (chunk_idx / len(chunks)) * 100
                self.progress_callback(f"Processing chunk {chunk_idx + 1}/{len(chunks)}", progress)
            
            # Process chunk in parallel
            with ThreadPoolExecutor(max_workers=4) as executor:
                future_to_file = {executor.submit(self.analyze_file, file_info): file_info for file_info in chunk}
                
                for future in as_completed(future_to_file):
                    result = future.result()
                    all_results.append(result)
                    processed_files += 1
        
        # Compile final results
        if self.progress_callback:
            self.progress_callback("Compiling results...", 95)
        
        total_issues = sum(len(result['findings']) for result in all_results)
        total_errors = sum(len(result['errors']) for result in all_results)
        
        # Generate project-level metrics and recommendations
        project_metrics = self._calculate_project_metrics(all_results)
        recommendations = self._generate_project_recommendations(all_results, project_metrics)
        
        analysis_time = time.time() - start_time
        
        if self.progress_callback:
            self.progress_callback("Analysis complete!", 100)
        
        return {
            'summary': {
                'total_files': total_files,
                'processed_files': processed_files,
                'total_issues': total_issues,
                'errors': total_errors,
                'analysis_time': analysis_time
            },
            'files': all_results,
            'project_metrics': project_metrics,
            'recommendations': recommendations
        }
    
    def _calculate_project_metrics(self, results: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Calculate project-level metrics"""
        total_lines = sum(result['metrics']['lines'] for result in results)
        total_complexity = sum(result['metrics']['complexity'] for result in results)
        total_functions = sum(result['metrics'].get('functions', 0) for result in results)
        total_classes = sum(result['metrics'].get('classes', 0) for result in results)
        
        # Security metrics
        severity_counts = {'CRITICAL': 0, 'HIGH': 0, 'MEDIUM': 0, 'LOW': 0}
        category_counts = {}
        
        for result in results:
            for finding in result['findings']:
                severity = finding['severity']
                category = finding.get('category', 'unknown')
                
                severity_counts[severity] += 1
                category_counts[category] = category_counts.get(category, 0) + 1
        
        return {
            'code_metrics': {
                'total_lines': total_lines,
                'average_complexity': total_complexity / len(results) if results else 0,
                'total_functions': total_functions,
                'total_classes': total_classes
            },
            'security_metrics': {
                'severity_distribution': severity_counts,
                'category_distribution': category_counts,
                'security_score': self._calculate_security_score(severity_counts)
            }
        }
    
    def _calculate_security_score(self, severity_counts: Dict[str, int]) -> int:
        """Calculate security score (0-100, higher is better)"""
        total_issues = sum(severity_counts.values())
        if total_issues == 0:
            return 100
        
        # Weight different severities
        weighted_score = (
            severity_counts['CRITICAL'] * 10 +
            severity_counts['HIGH'] * 5 +
            severity_counts['MEDIUM'] * 2 +
            severity_counts['LOW'] * 1
        )
        
        # Convert to 0-100 scale (inverse)
        max_possible_score = total_issues * 10  # If all were critical
        score = max(0, 100 - (weighted_score / max_possible_score * 100))
        
        return int(score)
    
    def _generate_project_recommendations(self, results: List[Dict[str, Any]], metrics: Dict[str, Any]) -> List[str]:
        """Generate project-level recommendations"""
        recommendations = []
        
        security_score = metrics['security_metrics']['security_score']
        severity_counts = metrics['security_metrics']['severity_distribution']
        
        # Security recommendations
        if security_score < 50:
            recommendations.append("🚨 URGENT: Security score is critically low. Immediate security review required.")
        elif security_score < 70:
            recommendations.append("⚠️ Security improvements needed. Consider implementing security best practices.")
        elif security_score < 90:
            recommendations.append("🔒 Good security posture. Minor improvements recommended.")
        else:
            recommendations.append("✅ Excellent security posture. Keep up the good work!")
        
        # Specific issue recommendations
        if severity_counts['CRITICAL'] > 0:
            recommendations.append(f"🔥 {severity_counts['CRITICAL']} critical security issues require immediate attention")
        
        if severity_counts['HIGH'] > 5:
            recommendations.append("🔑 Consider implementing automated security scanning in CI/CD pipeline")
        
        # Code quality recommendations
        avg_complexity = metrics['code_metrics']['average_complexity']
        if avg_complexity > 10:
            recommendations.append("📊 High code complexity detected. Consider refactoring complex functions.")
        
        # ML-specific recommendations
        ml_files = [r for r in results if any('ml' in f['category'] for f in [{'category': 'ml_model'}] if 'ml_model' in str(r))]
        if ml_files:
            recommendations.append("🤖 ML project detected. Implement model validation and secure model loading practices.")
        
        return recommendations
    
    def generate_fixed_file(self, file_path: str, findings: List[Dict[str, Any]]) -> str:
        """Generate a fixed version of the file"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            lines = content.split('\n')
            
            # Sort findings by line number (reverse order to maintain line numbers)
            sorted_findings = sorted(findings, key=lambda x: x['line'], reverse=True)
            
            for finding in sorted_findings:
                line_idx = finding['line'] - 1
                if 0 <= line_idx < len(lines):
                    original_line = lines[line_idx]
                    
                    # Apply fixes based on category
                    if finding['category'] == 'dangerous_function':
                        lines[line_idx] = self._fix_dangerous_function(original_line, finding)
                    elif finding['category'] == 'hardcoded_credential':
                        lines[line_idx] = self._fix_hardcoded_credential(original_line, finding)
                    elif finding['category'] == 'weak_crypto':
                        lines[line_idx] = self._fix_weak_crypto(original_line, finding)
                    
                    # Add comment explaining the fix
                    lines.insert(line_idx, f"    # SECURITY FIX: {finding['message']}")
            
            # Add imports if needed
            if any('os.getenv' in line for line in lines) and 'import os' not in content:
                lines.insert(0, 'import os')
            
            return '\n'.join(lines)
            
        except Exception as e:
            return f"# ERROR: Could not generate fixed file: {str(e)}\n\n{content}"
    
    def _fix_dangerous_function(self, line: str, finding: Dict[str, Any]) -> str:
        """Fix dangerous function calls"""
        if 'eval(' in line:
            return line.replace('eval(', 'ast.literal_eval(')
        elif 'exec(' in line:
            return f"    # REMOVED: {line.strip()}  # Use safer alternatives"
        return line
    
    def _fix_hardcoded_credential(self, line: str, finding: Dict[str, Any]) -> str:
        """Fix hardcoded credentials"""
        # Extract variable name
        if '=' in line:
            var_name = line.split('=')[0].strip()
            return f"{var_name} = os.getenv('{var_name.upper()}', 'default_value')"
        return line
    
    def _fix_weak_crypto(self, line: str, finding: Dict[str, Any]) -> str:
        """Fix weak cryptographic functions"""
        line = line.replace('hashlib.md5(', 'hashlib.sha256(')
        line = line.replace('hashlib.sha1(', 'hashlib.sha256(')
        line = line.replace('.md5()', '.sha256()')
        line = line.replace('.sha1()', '.sha256()')
        return line