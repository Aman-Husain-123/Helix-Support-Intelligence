import json
import sys
from typing import List, Dict, Any, Optional

class Finding:
    """
    Represents a single security vulnerability or code smell found.
    """
    def __init__(self, 
                 file: str, 
                 line: int, 
                 column: int, 
                 rule_name: str, 
                 message: str, 
                 severity: Optional[str] = None, 
                 description: Optional[str] = None,
                 remediation: Optional[str] = None,
                 potential_impact: Optional[str] = None) -> None:
        self.file: str = file
        self.line: int = line
        self.column: int = column
        self.rule_name: str = rule_name
        self.message: str = message
        self.severity: Optional[str] = severity
        self.description: Optional[str] = description
        self.remediation: Optional[str] = remediation
        self.potential_impact: Optional[str] = potential_impact

    def to_dict(self) -> Dict[str, Any]:
        return {
            "file": self.file,
            "line": self.line,
            "column": self.column,
            "rule_name": self.rule_name,
            "message": self.message,
            "severity": self.severity,
            "description": self.description,
            "remediation": self.remediation,
            "potential_impact": self.potential_impact
        }

class Report:
    """
    Manages a collection of findings and handles output formatting.
    """
    def __init__(self) -> None:
        self.findings: List[Finding] = []
        self.errors: List[Dict[str, Any]] = []
        self.total_files: int = 0

    def add_finding(self, finding: Finding) -> None:
        """Adds a Finding object to the report."""
        if isinstance(finding, Finding):
            self.findings.append(finding)
        else:
            raise TypeError("Expected Finding object")

    def add_error(self, file_path: str, error_type: str, message: str, lineno: Optional[int] = None) -> None:
        """Logs a parsing or system error."""
        self.errors.append({
            "file": file_path, 
            "type": error_type,
            "message": message,
            "line": lineno
        })

    def increment_file_count(self) -> None:
        self.total_files += 1

    def print_summary(self) -> None:
        """Prints a formatted summary to the console."""
        if not self.findings and not self.errors:
            print("\n" + "="*40)
            print("  CodeGuard: No issues found. [OK]")
            print("="*40 + "\n")
            return

        print(f"\n{'='*60}")
        print(f" CODEGUARD ANALYSIS SUMMARY")
        print(f" Analyzed {self.total_files} files")
        print(f" Found {len(self.findings)} potential issues.")
        print(f"{'='*60}")

        # Group findings by file
        grouped: Dict[str, List[Finding]] = {}
        for f in self.findings:
            grouped.setdefault(f.file, []).append(f)

        for file_path, file_findings in grouped.items():
            print(f"\nFile: {file_path}")
            for f in file_findings:
                sev = f"[{f.severity}] " if f.severity else ""
                print(f"  !!! {sev}Line {f.line}: {f.message} ({f.rule_name})")

        if self.errors:
            print(f"\n{'!'*60}")
            print(f" ERRORS ({len(self.errors)})")
            print(f"{'!'*60}")
            for err in self.errors:
                loc = f" (Line {err['line']})" if err.get('line') else ""
                print(f"  [ERROR] {err['file']}: {err['type']} - {err['message']}{loc}")
        
        print(f"\n{'='*60}\n")

    def export_json(self, output_path: str) -> None:
        """Exports findings to a JSON file."""
        data: Dict[str, Any] = {
            "summary": {
                "total_files": self.total_files,
                "total_issues": len(self.findings),
                "errors": len(self.errors)
            },
            "findings": [f.to_dict() for f in self.findings],
            "errors": self.errors
        }
        try:
            with open(output_path, 'w', encoding='utf-8') as f_out:
                json.dump(data, f_out, indent=4)
            print(f"Report exported to JSON: {output_path}")
        except Exception as e:
            print(f"Error exporting JSON: {e}", file=sys.stderr)

    def export_txt(self, output_path: str) -> None:
        """Exports findings to a text file."""
        try:
            with open(output_path, 'w', encoding='utf-8') as out_file:
                out_file.write("CodeGuard Analysis Report\n")
                out_file.write("="*60 + "\n\n")
                out_file.write(f"Files Analyzed: {self.total_files}\n")
                out_file.write(f"Issues Found: {len(self.findings)}\n\n")
                
                for f in self.findings:
                    out_file.write(f"File: {f.file}\n")
                    out_file.write(f"  Line {f.line}: {f.message} ({f.rule_name})\n")
                    if f.remediation:
                        out_file.write(f"  Suggested Fix: {f.remediation}\n")
                    out_file.write("\n")
            print(f"Report exported to Text: {output_path}")
        except Exception as e:
            print(f"Error exporting Text: {e}", file=sys.stderr)
