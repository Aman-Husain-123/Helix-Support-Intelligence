import json
import sys

class Reporter:
    """
    Utility class for rendering analysis Reports.
    """
    
    @staticmethod
    def to_console(report):
        """
        Prints a formatted summary of the Report object to the console.
        """
        findings = report.findings
        errors = report.errors
        summary = report.summary

        if not findings and not errors:
            print("\n" + "="*40)
            print("  CodeGuard: No issues found. [OK]")
            print("="*40 + "\n")
            return

        print(f"\n{'='*60}")
        print(f" CODEGUARD ANALYSIS SUMMARY")
        print(f" Analyzed {summary['total_files']} files")
        print(f" Found {summary['total_issues']} potential issues.")
        print(f"{'='*60}")

        # Group findings by file for better display
        grouped_findings = {}
        for f in findings:
            grouped_findings.setdefault(f['file'], []).append(f)

        for file_path, file_findings in grouped_findings.items():
            print(f"\nFile: {file_path}")
            for f in file_findings:
                severity_label = "!!!" if f['severity'] in ["CRITICAL", "HIGH"] else "!"
                print(f"  {severity_label} [{f['rule_id']}] Line {f['line']}: {f['message']}")
                print(f"      Description: {f['description']}")

        if errors:
            print(f"\n{'!'*60}")
            print(f" ERRORS ({len(errors)})")
            print(f"{'!'*60}")
            for err in errors:
                print(f"  [ERROR] {err['file']}: {err['type']} - {err['message']} (Line {err.get('line', '?')})")
        
        print(f"\n{'='*60}\n")

    @staticmethod
    def to_json(report, output_path):
        """
        Exports the Report object data to a JSON file.
        """
        data = {
            "summary": report.summary,
            "findings": report.findings,
            "errors": report.errors
        }
        try:
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=4)
            print(f"Report exported to JSON: {output_path}")
        except Exception as e:
            print(f"Error exporting JSON: {e}", file=sys.stderr)

    @staticmethod
    def to_txt(report, output_path):
        """
        Exports the Report object to a plain text file.
        """
        try:
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write("CodeGuard Analysis Report\n")
                f.write("="*60 + "\n\n")
                f.write(f"Files Analyzed: {report.summary['total_files']}\n")
                f.write(f"Issues Found: {report.summary['total_issues']}\n\n")
                
                for f_item in report.findings:
                    f.write(f"File: {f_item['file']}\n")
                    f.write(f"  [{f_item['severity']}] Line {f_item['line']}: {f_item['message']}\n")
                    f.write(f"  Description: {f_item['description']}\n\n")
                
                if report.errors:
                    f.write("-" * 60 + "\n")
                    f.write("Errors:\n")
                    for err in report.errors:
                        f.write(f"  {err['file']}: {err['message']}\n")
            
            print(f"Report exported to Text: {output_path}")
        except Exception as e:
            print(f"Error exporting Text: {e}", file=sys.stderr)
