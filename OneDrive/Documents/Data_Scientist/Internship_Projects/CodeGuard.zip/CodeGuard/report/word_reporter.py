from docx import Document
from docx.shared import Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from typing import List
from .report import Finding, Report
import io

class WordReporter:
    """
    Generates a professional Word document (.docx) analysis report.
    """
    @staticmethod
    def generate(report: Report) -> io.BytesIO:
        doc = Document()
        
        # Style setup
        style = doc.styles['Normal']
        font = style.font
        font.name = 'Arial'
        font.size = Pt(11)

        # Title
        title = doc.add_heading('CodeGuard Analysis Report', 0)
        title.alignment = WD_ALIGN_PARAGRAPH.CENTER

        # Summary Section
        doc.add_heading('1. Executive Summary', level=1)
        doc.add_paragraph(f"Total Files Analyzed: {report.total_files}")
        doc.add_paragraph(f"Total Issues Found: {len(report.findings)}")
        doc.add_paragraph(f"Total Parsing Errors: {len(report.errors)}")

        # Findings Section
        doc.add_heading('2. Detailed Findings', level=1)
        if not report.findings:
            doc.add_paragraph("No security vulnerabilities were identified in the analyzed code.")
        else:
            for i, f in enumerate(report.findings, 1):
                p = doc.add_paragraph()
                run = p.add_run(f"{i}. {f.rule_name} (Severity: {f.severity})")
                run.bold = True
                if f.severity == "CRITICAL":
                    run.font.color.rgb = RGBColor(255, 0, 0)
                elif f.severity == "HIGH":
                    run.font.color.rgb = RGBColor(255, 69, 0)

                doc.add_paragraph(f"File: {f.file}")
                doc.add_paragraph(f"Location: Line {f.line}, Column {f.column}")
                doc.add_paragraph(f"Issue: {f.message}")
                doc.add_paragraph(f"Description: {f.description}")
                doc.add_paragraph("-" * 20)

        # Errors Section
        if report.errors:
            doc.add_heading('3. Processing Errors', level=1)
            for err in report.errors:
                doc.add_paragraph(f"File: {err['file']}")
                doc.add_paragraph(f"Error: {err['type']} - {err['message']} (Line: {err.get('line', 'N/A')})")
                doc.add_paragraph("-" * 20)

        # Save to byte stream
        file_stream = io.BytesIO()
        doc.save(file_stream)
        file_stream.seek(0)
        return file_stream
