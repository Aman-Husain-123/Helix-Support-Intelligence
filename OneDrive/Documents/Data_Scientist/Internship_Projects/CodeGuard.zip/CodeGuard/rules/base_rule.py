from abc import ABC, abstractmethod
import ast
from typing import Optional, Dict, Any

class Rule(ABC):
    """
    Abstract base class for all static analysis rules.
    """
    
    def __init__(self, name: str, description: str, severity: str, remediation: str = "", potential_impact: str = "") -> None:
        """
        Initialize the rule.
        
        Args:
            name (str): The unique name/ID of the rule (e.g., 'C001').
            description (str): A brief description of what the rule checks.
            severity (str): The severity level (e.g., 'INFO', 'WARNING', 'ERROR').
            remediation (str): Suggestion on how to fix the issue.
            potential_impact (str): Description of the potential impact if the rule is violated.
        """
        self.name: str = name
        self.description: str = description
        self.severity: str = severity
        self.remediation: str = remediation
        self.potential_impact: str = potential_impact

    @abstractmethod
    def check(self, node: ast.AST) -> Optional[Dict[str, Any]]:
        """
        Analyze a single AST node for rule violations.
        """
        pass
