import ast
from typing import Optional, Dict, Any, Set
from .base_rule import Rule

class DangerousFunctionsRule(Rule):
    """
    Detects the use of dangerous functions like eval() and exec().
    """

    def __init__(self) -> None:
        super().__init__(
            name="S001",
            description="Use of eval() or exec() detected. These functions can execute arbitrary code.",
            severity="CRITICAL",
            remediation="Avoid using eval() or exec(). Instead, use safer alternatives like literal_eval from the ast module for evaluating literals, or redesign the logic to avoid dynamic code execution.",
            potential_impact="Remote Code Execution (RCE). An attacker could execute arbitrary system commands, leading to full server compromise."
        )
        self.dangerous_funcs: Set[str] = {'eval', 'exec'}

    def check(self, node: ast.AST) -> Optional[Dict[str, Any]]:
        """
        Checks if a single node is a call to eval() or exec().
        """
        if isinstance(node, ast.Call):
            if isinstance(node.func, ast.Name):
                if node.func.id in self.dangerous_funcs:
                    return {
                        "line": node.lineno,
                        "column": node.col_offset,
                        "message": f"Dangerous function '{node.func.id}' called."
                    }
        return None

class HardcodedCredentialsRule(Rule):
    """
    Detects potential hardcoded credentials like passwords and secret keys.
    """

    def __init__(self) -> None:
        super().__init__(
            name="S002",
            description="Potential hardcoded credential detected in variable assignment.",
            severity="HIGH",
            remediation="🛑 **Best Practice**: Move this value to a `.env` file and use the `python-dotenv` library to load it. \n\n*Example*:\n`API_TOKEN = os.getenv('API_TOKEN')`",
            potential_impact="Data Breach & Unauthorized Access. Exposed API keys or passwords allow attackers to bypass security layers and access sensitive databases or third-party services."
        )
        self.secret_keywords: Set[str] = {'password', 'secret', 'api_key', 'token', 'db', 'url', 'database', 'conn', 'cred', 'login', 'pass', 'hash', 'key'}

    def check(self, node: ast.AST) -> Optional[Dict[str, Any]]:
        """
        Checks if a single node is an assignment of a string literal to a sensitive variable name.
        """
        if isinstance(node, ast.Assign):
            if isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
                for target in node.targets:
                    if isinstance(target, ast.Name):
                        var_name = target.id.lower()
                        if any(key in var_name for key in self.secret_keywords):
                            return {
                                "line": node.lineno,
                                "column": node.col_offset,
                                "message": f"Potential hardcoded credential found in variable '{target.id}'."
                            }
        return None

class WeakHashingRule(Rule):
    """
    Detects the use of weak hashing algorithms like MD5 or SHA1.
    """

    def __init__(self) -> None:
        super().__init__(
            name="S003",
            description="Use of weak hashing algorithm (MD5/SHA1) detected.",
            severity="MEDIUM",
            remediation="Replace insecure hashing algorithms like MD5 or SHA1 with stronger alternatives such as SHA-256 or SHA-512 from the hashlib module.",
            potential_impact="Credential Compromise. Broken algorithms are vulnerable to collision and rainbow table attacks, allowing attackers to recover plain-text passwords."
        )
        self.weak_algorithms: Set[str] = {'md5', 'sha1'}

    def check(self, node: ast.AST) -> Optional[Dict[str, Any]]:
        """
        Checks if a single node is a call to a weak hashing algorithm.
        """
        if isinstance(node, ast.Call):
            func_name: str = ""
            if isinstance(node.func, ast.Attribute):
                if node.func.attr in self.weak_algorithms:
                    func_name = node.func.attr
            elif isinstance(node.func, ast.Name):
                if node.func.id in self.weak_algorithms:
                    func_name = node.func.id
            
            if func_name:
                return {
                    "line": node.lineno,
                    "column": node.col_offset,
                    "message": f"Weak hashing algorithm '{func_name}' used."
                }
        return None
