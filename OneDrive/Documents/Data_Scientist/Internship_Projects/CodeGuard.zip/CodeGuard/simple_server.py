#!/usr/bin/env python3
"""
Simple, fast Flask server for CodeGuard AI
Optimized for speed and reliability
"""
import os
import ast
import tempfile
import uuid
from datetime import datetime
from flask import Flask, request, jsonify, render_template
from flask_cors import CORS

# Simple analyzer without external dependencies
class SimpleAnalyzer:
    def __init__(self):
        self.dangerous_funcs = {'eval', 'exec'}
        self.secret_keywords = {'password', 'secret', 'api_key', 'token', 'key'}
        self.weak_hashes = {'md5', 'sha1'}
    
    def analyze_code(self, code):
        findings = []
        errors = []
        
        try:
            tree = ast.parse(code)
            
            for node in ast.walk(tree):
                # Check for dangerous functions
                if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
                    if node.func.id in self.dangerous_funcs:
                        findings.append({
                            'line': node.lineno,
                            'severity': 'CRITICAL',
                            'message': f"Dangerous function '{node.func.id}' detected",
                            'remediation': f"Replace {node.func.id}() with safer alternatives like ast.literal_eval()"
                        })
                
                # Check for hardcoded credentials
                if isinstance(node, ast.Assign) and isinstance(node.value, ast.Constant):
                    if isinstance(node.value.value, str):
                        for target in node.targets:
                            if isinstance(target, ast.Name):
                                var_name = target.id.lower()
                                if any(keyword in var_name for keyword in self.secret_keywords):
                                    findings.append({
                                        'line': node.lineno,
                                        'severity': 'HIGH',
                                        'message': f"Hardcoded credential in variable '{target.id}'",
                                        'remediation': f"Move '{target.id}' to environment variables using os.getenv()"
                                    })
                
                # Check for weak hashing
                if isinstance(node, ast.Call):
                    func_name = ""
                    if isinstance(node.func, ast.Attribute) and node.func.attr in self.weak_hashes:
                        func_name = node.func.attr
                    elif isinstance(node.func, ast.Name) and node.func.id in self.weak_hashes:
                        func_name = node.func.id
                    
                    if func_name:
                        findings.append({
                            'line': node.lineno,
                            'severity': 'MEDIUM',
                            'message': f"Weak hashing algorithm '{func_name}' detected",
                            'remediation': f"Replace {func_name} with SHA-256 or stronger algorithm"
                        })
        
        except SyntaxError as e:
            errors.append({
                'file': 'input',
                'type': 'SyntaxError',
                'message': str(e)
            })
        except Exception as e:
            errors.append({
                'file': 'input',
                'type': 'AnalysisError',
                'message': str(e)
            })
        
        return {
            'findings': findings,
            'errors': errors,
            'summary': {
                'total_files': 1,
                'total_issues': len(findings),
                'errors': len(errors)
            }
        }

# Initialize Flask App
app = Flask(__name__, template_folder='templates', static_folder='static')
CORS(app)

# Initialize simple analyzer
analyzer = SimpleAnalyzer()

@app.route('/')
def index():
    """Serves the main UI."""
    return render_template('index.html')

@app.route('/api/analyze', methods=['POST'])
def analyze_code():
    """Fast code analysis endpoint."""
    try:
        data = request.json
        if not data:
            return jsonify({"error": "Invalid JSON"}), 400
            
        code = data.get('code', '').strip()
        if not code:
            return jsonify({"error": "No code provided"}), 400
        
        # Size limit for performance
        if len(code) > 50000:
            return jsonify({"error": "Code too large (max 50KB)"}), 400
        
        print(f"🔍 Analyzing {len(code)} characters...")
        
        # Fast analysis
        import time
        start_time = time.time()
        result = analyzer.analyze_code(code)
        analysis_time = time.time() - start_time
        
        result['id'] = str(uuid.uuid4())
        result['timestamp'] = datetime.now().isoformat()
        result['analysis_time'] = f"{analysis_time:.3f}s"
        
        print(f"✅ Analysis completed in {analysis_time:.3f}s - {len(result['findings'])} findings")
        
        return jsonify(result)
        
    except Exception as e:
        print(f"❌ Error: {e}")
        return jsonify({
            "error": "Analysis failed",
            "message": str(e)
        }), 500

@app.route('/api/fix', methods=['POST'])
def fix_code():
    """Simple code fixing."""
    try:
        data = request.json
        code = data.get('code', '')
        
        # Simple fixes
        fixed_code = code
        fixed_code = fixed_code.replace('eval(', '# FIXED: eval( -> ast.literal_eval(')
        fixed_code = fixed_code.replace('exec(', '# FIXED: exec( -> safer alternative needed')
        fixed_code = fixed_code.replace('hashlib.md5(', 'hashlib.sha256(')
        fixed_code = fixed_code.replace('hashlib.sha1(', 'hashlib.sha256(')
        
        # Add environment variable suggestions
        lines = fixed_code.split('\n')
        for i, line in enumerate(lines):
            if '=' in line and any(keyword in line.lower() for keyword in ['password', 'secret', 'key', 'token']):
                if '"' in line or "'" in line:
                    var_name = line.split('=')[0].strip()
                    lines[i] = f"# FIXED: {var_name} = os.getenv('{var_name.upper()}')"
        
        fixed_code = '\n'.join(lines)
        
        return jsonify({"fixedCode": fixed_code})
        
    except Exception as e:
        return jsonify({"fixedCode": f"# Fix failed: {e}\n\n{code}"})

@app.route('/api/status', methods=['GET'])
def status():
    """System status."""
    return jsonify({
        "status": "online",
        "version": "3.0.0_SIMPLE",
        "engine": "fast_analyzer"
    })

if __name__ == '__main__':
    print(f"\n{'='*50}")
    print("🛡️  CODEGUARD AI - SIMPLE & FAST")
    print(f"{'='*50}")
    print(f"🚀 Status: ONLINE")
    print(f"🌐 Interface: http://localhost:5001")
    print(f"⚡ Mode: High Performance")
    print(f"{'='*50}\n")
    
    app.run(host='0.0.0.0', port=5001, debug=False, threaded=True)