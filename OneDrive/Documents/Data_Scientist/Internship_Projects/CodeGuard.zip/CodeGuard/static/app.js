// CodeGuard AI - Advanced Project Analysis Interface
class CodeGuardApp {
    constructor() {
        this.editor = null;
        this.currentResults = null;
        this.currentAnalysisId = null;
        this.isScanning = false;
        this.analysisMode = 'single'; // 'single' or 'project'
        this.init();
    }

    async init() {
        await this.initializeEditor();
        this.bindEvents();
        this.showWelcomeMessage();
        this.setupModeToggle();
    }

    setupModeToggle() {
        // Add mode toggle buttons to the interface
        const header = document.querySelector('header');
        const modeToggle = document.createElement('div');
        modeToggle.className = 'mode-toggle';
        modeToggle.innerHTML = `
            <div class="toggle-buttons">
                <button id="singleModeBtn" class="toggle-btn active">Single File</button>
                <button id="projectModeBtn" class="toggle-btn">Project Upload</button>
            </div>
        `;
        header.appendChild(modeToggle);

        // Bind mode toggle events
        document.getElementById('singleModeBtn').addEventListener('click', () => this.switchMode('single'));
        document.getElementById('projectModeBtn').addEventListener('click', () => this.switchMode('project'));
    }

    switchMode(mode) {
        this.analysisMode = mode;
        
        // Update button states
        document.querySelectorAll('.toggle-btn').forEach(btn => btn.classList.remove('active'));
        document.getElementById(mode === 'single' ? 'singleModeBtn' : 'projectModeBtn').classList.add('active');
        
        // Update interface
        this.updateInterface();
    }

    updateInterface() {
        const editorSection = document.querySelector('.editor-section');
        
        if (this.analysisMode === 'single') {
            editorSection.innerHTML = `
                <div class="editor-container glass">
                    <div id="editor"></div>
                </div>
                <button id="scanBtn" class="btn scan-btn">
                    INITIALIZE SCAN
                </button>
            `;
            this.initializeEditor();
            document.getElementById('scanBtn').addEventListener('click', () => this.performScan());
        } else {
            editorSection.innerHTML = `
                <div class="upload-container glass">
                    <div class="upload-area" id="uploadArea">
                        <div class="upload-icon">📦</div>
                        <div class="upload-text">
                            <h3>Upload Python/ML Project</h3>
                            <p>Drop your ZIP file here or click to browse</p>
                            <small>Max size: 100MB | Supported: .zip files</small>
                        </div>
                        <input type="file" id="projectFile" accept=".zip" style="display: none;">
                    </div>
                    <div class="upload-progress" id="uploadProgress" style="display: none;">
                        <div class="progress-bar">
                            <div class="progress-fill" id="progressFill"></div>
                        </div>
                        <div class="progress-text" id="progressText">Uploading...</div>
                    </div>
                </div>
                <button id="uploadBtn" class="btn scan-btn" style="display: none;">
                    ANALYZE PROJECT
                </button>
            `;
            this.setupProjectUpload();
        }
        
        // Reset results
        this.currentResults = null;
        this.showWelcomeMessage();
    }

    setupProjectUpload() {
        const uploadArea = document.getElementById('uploadArea');
        const fileInput = document.getElementById('projectFile');
        const uploadBtn = document.getElementById('uploadBtn');

        // Click to upload
        uploadArea.addEventListener('click', () => fileInput.click());

        // Drag and drop
        uploadArea.addEventListener('dragover', (e) => {
            e.preventDefault();
            uploadArea.classList.add('drag-over');
        });

        uploadArea.addEventListener('dragleave', () => {
            uploadArea.classList.remove('drag-over');
        });

        uploadArea.addEventListener('drop', (e) => {
            e.preventDefault();
            uploadArea.classList.remove('drag-over');
            const files = e.dataTransfer.files;
            if (files.length > 0) {
                this.handleFileSelection(files[0]);
            }
        });

        // File selection
        fileInput.addEventListener('change', (e) => {
            if (e.target.files.length > 0) {
                this.handleFileSelection(e.target.files[0]);
            }
        });

        // Upload button
        uploadBtn.addEventListener('click', () => this.uploadProject());
    }

    handleFileSelection(file) {
        if (!file.name.endsWith('.zip')) {
            this.showError('Please select a ZIP file');
            return;
        }

        if (file.size > 100 * 1024 * 1024) {
            this.showError('File too large. Maximum size is 100MB');
            return;
        }

        this.selectedFile = file;
        document.getElementById('uploadBtn').style.display = 'block';
        
        // Update upload area
        const uploadArea = document.getElementById('uploadArea');
        uploadArea.innerHTML = `
            <div class="file-selected">
                <div class="file-icon">📁</div>
                <div class="file-info">
                    <div class="file-name">${file.name}</div>
                    <div class="file-size">${this.formatFileSize(file.size)}</div>
                </div>
                <button class="remove-file" onclick="location.reload()">×</button>
            </div>
        `;
    }

    async uploadProject() {
        if (!this.selectedFile) return;

        const uploadBtn = document.getElementById('uploadBtn');
        const progressContainer = document.getElementById('uploadProgress');
        
        uploadBtn.disabled = true;
        uploadBtn.textContent = 'UPLOADING...';
        progressContainer.style.display = 'block';

        try {
            const formData = new FormData();
            formData.append('project', this.selectedFile);

            const response = await fetch('/api/upload-project', {
                method: 'POST',
                body: formData
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.message || 'Upload failed');
            }

            const data = await response.json();
            this.currentAnalysisId = data.analysis_id;

            // Start polling for progress
            this.pollAnalysisProgress();

        } catch (error) {
            console.error('Upload error:', error);
            this.showError(`Upload failed: ${error.message}`);
            uploadBtn.disabled = false;
            uploadBtn.textContent = 'ANALYZE PROJECT';
            progressContainer.style.display = 'none';
        }
    }

    async pollAnalysisProgress() {
        if (!this.currentAnalysisId) return;

        try {
            const response = await fetch(`/api/analysis-progress/${this.currentAnalysisId}`);
            const data = await response.json();

            // Update progress
            const progressFill = document.getElementById('progressFill');
            const progressText = document.getElementById('progressText');
            
            if (progressFill && progressText) {
                progressFill.style.width = `${data.progress}%`;
                progressText.textContent = data.message;
            }

            if (data.status === 'complete') {
                // Analysis complete, fetch results
                await this.fetchAnalysisResults();
            } else {
                // Continue polling
                setTimeout(() => this.pollAnalysisProgress(), 1000);
            }

        } catch (error) {
            console.error('Progress polling error:', error);
            this.showError('Failed to get analysis progress');
        }
    }

    async fetchAnalysisResults() {
        try {
            const response = await fetch(`/api/analysis-results/${this.currentAnalysisId}`);
            const data = await response.json();

            this.currentResults = data;
            this.displayProjectResults(data);

            // Hide progress
            document.getElementById('uploadProgress').style.display = 'none';
            document.getElementById('uploadBtn').style.display = 'none';

        } catch (error) {
            console.error('Results fetch error:', error);
            this.showError('Failed to fetch analysis results');
        }
    }

    displayProjectResults(data) {
        if (data.error) {
            this.showError(`Analysis failed: ${data.error}`);
            return;
        }

        // Update metrics
        this.updateMetrics(data.summary);

        // Display comprehensive project results
        let html = `
            <div class="project-summary">
                <h3>📊 PROJECT ANALYSIS COMPLETE</h3>
                <div class="summary-stats">
                    <div class="stat">
                        <span class="stat-value">${data.summary.processed_files}</span>
                        <span class="stat-label">Files Analyzed</span>
                    </div>
                    <div class="stat">
                        <span class="stat-value">${data.summary.total_issues}</span>
                        <span class="stat-label">Issues Found</span>
                    </div>
                    <div class="stat">
                        <span class="stat-value">${data.summary.analysis_time.toFixed(1)}s</span>
                        <span class="stat-label">Analysis Time</span>
                    </div>
                </div>
            </div>
        `;

        // Security score
        if (data.project_metrics && data.project_metrics.security_metrics) {
            const score = data.project_metrics.security_metrics.security_score;
            const scoreClass = score >= 80 ? 'good' : score >= 60 ? 'warning' : 'critical';
            
            html += `
                <div class="security-score ${scoreClass}">
                    <div class="score-circle">
                        <span class="score-value">${score}</span>
                    </div>
                    <div class="score-text">Security Score</div>
                </div>
            `;
        }

        // Recommendations
        if (data.recommendations && data.recommendations.length > 0) {
            html += `
                <div class="recommendations">
                    <h4>💡 RECOMMENDATIONS</h4>
                    ${data.recommendations.map(rec => `<div class="recommendation">${rec}</div>`).join('')}
                </div>
            `;
        }

        // File-by-file results
        if (data.files && data.files.length > 0) {
            html += `
                <div class="file-results">
                    <h4>📁 FILE ANALYSIS</h4>
                    <div class="file-list">
            `;

            // Group files by category
            const filesByCategory = {};
            data.files.forEach(file => {
                const category = this.getFileCategory(file);
                if (!filesByCategory[category]) filesByCategory[category] = [];
                filesByCategory[category].push(file);
            });

            Object.entries(filesByCategory).forEach(([category, files]) => {
                html += `
                    <div class="file-category">
                        <h5>${this.getCategoryIcon(category)} ${category.toUpperCase()}</h5>
                        ${files.map(file => this.renderFileResult(file)).join('')}
                    </div>
                `;
            });

            html += `
                    </div>
                </div>
            `;
        }

        this.updateFeed(html);
        
        // Show fix button if there are issues
        if (data.summary.total_issues > 0) {
            document.getElementById('fixBtn').style.display = 'block';
        }
    }

    getFileCategory(file) {
        const path = file.file.toLowerCase();
        if (path.includes('test')) return 'Tests';
        if (path.includes('model') || path.includes('ml')) return 'ML Models';
        if (path.includes('config') || path.includes('setting')) return 'Configuration';
        if (path.includes('api') || path.includes('server')) return 'API/Server';
        return 'Core';
    }

    getCategoryIcon(category) {
        const icons = {
            'Tests': '🧪',
            'ML Models': '🤖',
            'Configuration': '⚙️',
            'API/Server': '🌐',
            'Core': '💻'
        };
        return icons[category] || '📄';
    }

    renderFileResult(file) {
        const issueCount = file.findings.length;
        const severityClass = issueCount === 0 ? 'clean' : issueCount < 3 ? 'low' : issueCount < 6 ? 'medium' : 'high';
        
        return `
            <div class="file-item ${severityClass}" onclick="this.classList.toggle('expanded')">
                <div class="file-header">
                    <span class="file-name">${file.file}</span>
                    <span class="issue-count">${issueCount} issues</span>
                </div>
                <div class="file-details">
                    ${file.findings.map(finding => `
                        <div class="finding-item">
                            <span class="severity-badge severity-${finding.severity.toLowerCase()}">${finding.severity}</span>
                            <span class="finding-message">${finding.message}</span>
                            <div class="finding-remediation">${finding.remediation}</div>
                        </div>
                    `).join('')}
                    ${file.suggestions.length > 0 ? `
                        <div class="suggestions">
                            <strong>Suggestions:</strong>
                            ${file.suggestions.map(s => `<div class="suggestion">${s}</div>`).join('')}
                        </div>
                    ` : ''}
                    <button class="generate-fix-btn" onclick="event.stopPropagation(); window.app.generateFixedFile('${file.file}')">
                        Generate Fixed File
                    </button>
                </div>
            </div>
        `;
    }

    async generateFixedFile(filePath) {
        try {
            const response = await fetch('/api/generate-fixed-file', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    analysis_id: this.currentAnalysisId,
                    file_path: filePath
                })
            });

            const data = await response.json();
            this.showFixedCode(`Fixed: ${filePath}`, data.fixed_content);

        } catch (error) {
            console.error('Fix generation error:', error);
            this.showError('Failed to generate fixed file');
        }
    }

    async initializeEditor() {
        if (this.analysisMode !== 'single') return;
        
        return new Promise((resolve) => {
            require.config({ 
                paths: { 
                    vs: 'https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.44.0/min/vs' 
                } 
            });
            
            require(['vs/editor/editor.main'], () => {
                const editorElement = document.getElementById('editor');
                if (editorElement) {
                    this.editor = monaco.editor.create(editorElement, {
                        value: this.getDefaultCode(),
                        language: 'python',
                        theme: 'vs-dark',
                        fontSize: 16,
                        fontFamily: 'Fira Code, monospace',
                        minimap: { enabled: false },
                        scrollBeyondLastLine: false,
                        automaticLayout: true,
                        lineNumbers: 'on',
                        renderWhitespace: 'selection',
                        cursorBlinking: 'smooth',
                        cursorSmoothCaretAnimation: true,
                        smoothScrolling: true,
                        mouseWheelZoom: true
                    });
                }
                resolve();
            });
        });
    }

    getDefaultCode() {
        return `import os
import subprocess
import pickle
import hashlib

# ML/Data Science Security Demo
import joblib
import torch
import pandas as pd

# Hardcoded credentials (SECURITY ISSUE)
API_KEY = "sk_live_12345_secret_key"
DATABASE_PASSWORD = "admin123"
ML_MODEL_TOKEN = "model_access_token_xyz"

def load_model(model_path):
    # Insecure model loading (SECURITY ISSUE)
    return torch.load(model_path)  # Should use weights_only=True

def execute_command(user_input):
    # Command injection vulnerability (CRITICAL)
    result = subprocess.run(user_input, shell=True, capture_output=True)
    return result.stdout

def load_user_data(filename):
    # Insecure deserialization (HIGH RISK)
    with open(filename, 'rb') as f:
        return pickle.load(f)

def hash_password(password):
    # Weak hashing algorithm (MEDIUM RISK)
    return hashlib.md5(password.encode()).hexdigest()

def process_data(data_source):
    # Dynamic code execution (CRITICAL)
    return eval(data_source)

# ML-specific security issues
def load_pretrained_model(url):
    # Downloading and loading untrusted models
    model_data = joblib.load(url)  # Should validate source
    return model_data

if __name__ == "__main__":
    user_cmd = input("Enter command: ")
    execute_command(user_cmd)`;
    }

    bindEvents() {
        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            if (e.ctrlKey && e.key === 'Enter') {
                e.preventDefault();
                if (this.analysisMode === 'single') {
                    this.performScan();
                }
            }
        });
    }

    showWelcomeMessage() {
        const message = this.analysisMode === 'single' 
            ? `<div class="empty-state">
                <div class="empty-icon">🛡️</div>
                <div class="empty-text">NEURAL ENGINE READY</div>
                <div style="margin-top: 1rem; font-size: 0.7rem; opacity: 0.5;">
                    Paste your code and press CTRL+ENTER to scan
                </div>
            </div>`
            : `<div class="empty-state">
                <div class="empty-icon">📦</div>
                <div class="empty-text">PROJECT ANALYZER READY</div>
                <div style="margin-top: 1rem; font-size: 0.7rem; opacity: 0.5;">
                    Upload your Python/ML project ZIP file for comprehensive analysis
                </div>
            </div>`;
        
        this.updateFeed(message);
    }

    async performScan() {
        if (this.isScanning || this.analysisMode !== 'single') return;

        const scanBtn = document.getElementById('scanBtn');
        const code = this.editor.getValue().trim();

        if (!code) {
            this.showError('No source code provided');
            return;
        }

        if (code.length > 100000) {
            this.showError('Code too large. Please limit to 100KB for fast analysis.');
            return;
        }

        this.isScanning = true;
        scanBtn.disabled = true;
        scanBtn.textContent = 'SCANNING...';
        scanBtn.classList.add('loading');

        this.updateFeed(`
            <div class="empty-state">
                <div class="empty-icon">⚡</div>
                <div class="empty-text">FAST NEURAL ANALYSIS</div>
                <div style="margin-top: 1rem; font-size: 0.7rem; opacity: 0.5;">
                    Processing ${Math.round(code.length / 1000)}KB of code...
                </div>
            </div>
        `);

        const startTime = performance.now();

        try {
            const response = await fetch('/api/analyze', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ code })
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.message || `HTTP ${response.status}: ${response.statusText}`);
            }

            this.currentResults = await response.json();
            const analysisTime = performance.now() - startTime;
            
            console.log(`Analysis completed in ${analysisTime.toFixed(0)}ms`);
            this.displayResults(this.currentResults);

        } catch (error) {
            console.error('Scan error:', error);
            this.showError(`Scan failed: ${error.message}`);
        } finally {
            this.isScanning = false;
            scanBtn.disabled = false;
            scanBtn.textContent = 'INITIALIZE SCAN';
            scanBtn.classList.remove('loading');
        }
    }

    async generateFix() {
        if (!this.currentResults) return;

        const fixBtn = document.getElementById('fixBtn');
        const code = this.analysisMode === 'single' ? this.editor.getValue() : '';

        fixBtn.disabled = true;
        fixBtn.textContent = 'RECONSTRUCTING...';
        fixBtn.classList.add('loading');

        try {
            const response = await fetch('/api/fix', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ 
                    code, 
                    auditId: this.currentResults.id 
                })
            });

            const data = await response.json();
            this.showFixedCode('Secure Code Generated', data.fixedCode);

        } catch (error) {
            console.error('Fix error:', error);
            this.showError(`Code reconstruction failed: ${error.message}`);
        } finally {
            fixBtn.disabled = false;
            fixBtn.textContent = 'GENERATE SECURE CODE';
            fixBtn.classList.remove('loading');
        }
    }

    displayResults(data) {
        this.updateMetrics(data);

        if (data.findings && data.findings.length > 0) {
            this.displayFindings(data.findings);
            document.getElementById('fixBtn').style.display = 'block';
        } else if (data.errors && data.errors.length > 0) {
            this.displayErrors(data.errors);
        } else {
            this.showSuccessState();
        }
    }

    updateMetrics(data) {
        const threats = data.total_issues || 0;
        const assets = data.total_files || 1;
        const integrity = data.errors || 0;

        this.animateCounter('threats', threats, 'metric-threats');
        this.animateCounter('assets', assets, 'metric-assets');
        this.animateCounter('integrity', integrity, 'metric-integrity');
    }

    animateCounter(elementId, targetValue, className) {
        const element = document.getElementById(elementId);
        if (!element) return;
        
        const startValue = parseInt(element.textContent) || 0;
        const duration = 1000;
        const startTime = performance.now();

        const animate = (currentTime) => {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);
            
            const currentValue = Math.floor(startValue + (targetValue - startValue) * progress);
            element.textContent = currentValue;
            
            if (progress < 1) {
                requestAnimationFrame(animate);
            }
        };

        requestAnimationFrame(animate);
    }

    displayFindings(findings) {
        let html = '';
        
        findings.forEach((finding, index) => {
            const severity = finding.severity || 'INFO';
            const severityClass = `severity-${severity.toLowerCase()}`;
            
            html += `
                <div class="finding-card fade-in" style="animation-delay: ${index * 0.1}s">
                    <div class="finding-header">
                        <span class="severity-badge ${severityClass}">${severity}</span>
                        <span class="line-number">LINE ${finding.line}</span>
                    </div>
                    <div class="finding-message">${this.escapeHtml(finding.message)}</div>
                    <div class="finding-remediation">
                        ${this.escapeHtml(finding.remediation || 'No specific remediation provided')}
                    </div>
                </div>
            `;
        });

        this.updateFeed(html);
    }

    displayErrors(errors) {
        let html = '';
        
        errors.forEach((error, index) => {
            html += `
                <div class="finding-card error-card fade-in" style="animation-delay: ${index * 0.1}s">
                    <div class="finding-header">
                        <span class="severity-badge severity-critical">ERROR</span>
                        <span class="line-number">${error.file || 'SYSTEM'}</span>
                    </div>
                    <div class="finding-message">Engine Violation</div>
                    <div class="finding-remediation">
                        ${this.escapeHtml(error.message)}
                    </div>
                </div>
            `;
        });

        this.updateFeed(html);
    }

    showSuccessState() {
        this.updateFeed(`
            <div class="success-state">
                <div class="success-icon">✅</div>
                <div class="success-text">NO THREATS DETECTED</div>
                <div style="margin-top: 1rem; font-size: 0.7rem; opacity: 0.5;">
                    Your code appears to be secure
                </div>
            </div>
        `);
    }

    showError(message) {
        this.updateFeed(`
            <div class="finding-card error-card">
                <div class="finding-header">
                    <span class="severity-badge severity-critical">SYSTEM ERROR</span>
                </div>
                <div class="finding-message">Analysis Failed</div>
                <div class="finding-remediation">
                    ${this.escapeHtml(message)}
                </div>
            </div>
        `);
    }

    showFixedCode(title, code) {
        const modal = this.createModal(title, code);
        document.body.appendChild(modal);
        
        setTimeout(() => {
            if (modal.parentNode) {
                modal.parentNode.removeChild(modal);
            }
        }, 30000);
    }

    createModal(title, code) {
        const modal = document.createElement('div');
        modal.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            backdrop-filter: blur(10px);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 1000;
        `;

        const content = document.createElement('div');
        content.style.cssText = `
            background: var(--secondary-bg);
            border: 1px solid var(--border-color);
            border-radius: 24px;
            padding: 2rem;
            max-width: 80%;
            max-height: 80%;
            overflow: auto;
            position: relative;
        `;

        content.innerHTML = `
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                <h3 style="color: var(--accent-blue); font-size: 1.5rem; font-weight: 700;">${title}</h3>
                <button onclick="this.closest('[style*=\"position: fixed\"]').remove()" 
                        style="background: none; border: none; color: var(--text-secondary); font-size: 1.5rem; cursor: pointer;">×</button>
            </div>
            <pre style="background: var(--primary-bg); padding: 1.5rem; border-radius: 12px; overflow: auto; font-family: 'Fira Code', monospace; font-size: 0.9rem; line-height: 1.5; color: var(--text-primary);">${this.escapeHtml(code)}</pre>
            <div style="margin-top: 1rem; text-align: center;">
                <button onclick="navigator.clipboard.writeText(\`${code.replace(/`/g, '\\`')}\`).then(() => alert('Code copied to clipboard!'))" 
                        class="btn" style="margin-right: 1rem;">Copy Code</button>
                <button onclick="this.closest('[style*=\"position: fixed\"]').remove()" 
                        class="btn btn-secondary">Close</button>
            </div>
        `;

        modal.appendChild(content);
        
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.remove();
            }
        });

        return modal;
    }

    updateFeed(html) {
        const feedContent = document.getElementById('feed');
        if (feedContent) {
            feedContent.innerHTML = html;
            feedContent.scrollTop = 0;
        }
    }

    formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.app = new CodeGuardApp();
    
    // Bind fix button
    const fixBtn = document.getElementById('fixBtn');
    if (fixBtn) {
        fixBtn.addEventListener('click', () => window.app.generateFix());
    }
});

// Global error handler
window.addEventListener('error', (e) => {
    console.error('Global error:', e.error);
});

// Service worker registration (optional, for offline support)
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/static/sw.js')
            .then(registration => console.log('SW registered'))
            .catch(error => console.log('SW registration failed'));
    });
}