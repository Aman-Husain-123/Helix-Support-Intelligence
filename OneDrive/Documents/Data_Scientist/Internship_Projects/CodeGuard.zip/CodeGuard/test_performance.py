#!/usr/bin/env python3
"""
Quick performance test for CodeGuard Flask API
"""
import requests
import time
import json

# Test code with various security issues
test_code = '''
import os
import subprocess
import pickle
import hashlib

# Hardcoded credentials
API_KEY = "sk_live_12345_secret_key"
DATABASE_PASSWORD = "admin123"
JWT_SECRET = "my_super_secret_jwt_key"

def execute_command(user_input):
    # Command injection vulnerability
    result = subprocess.run(user_input, shell=True, capture_output=True)
    return result.stdout

def load_user_data(filename):
    # Insecure deserialization
    with open(filename, 'rb') as f:
        return pickle.load(f)

def authenticate(username, password):
    # SQL injection vulnerability (simulated)
    query = f"SELECT * FROM users WHERE username='{username}' AND password='{password}'"
    return query

def hash_password(password):
    # Weak hashing
    return hashlib.md5(password.encode()).hexdigest()

def process_file(filepath):
    # Path traversal vulnerability
    with open(f"/uploads/{filepath}", 'r') as f:
        return f.read()

def dangerous_eval(user_code):
    # Code injection
    return eval(user_code)

# More hardcoded secrets
admin_token = "hardcoded_admin_token_123"
db_url = "postgresql://user:pass@localhost/db"

if __name__ == "__main__":
    user_cmd = input("Enter command: ")
    execute_command(user_cmd)
    
    user_code = input("Enter Python code: ")
    dangerous_eval(user_code)
'''

def test_api_performance():
    """Test the Flask API performance"""
    url = "http://localhost:5001/api/analyze"
    
    print("🧪 Testing CodeGuard Flask API Performance...")
    print(f"📊 Test code size: {len(test_code)} characters")
    
    try:
        start_time = time.time()
        
        response = requests.post(url, json={
            "code": test_code,
            "filename": "performance_test.py"
        }, timeout=30)
        
        end_time = time.time()
        analysis_time = end_time - start_time
        
        if response.status_code == 200:
            data = response.json()
            print(f"✅ Analysis completed successfully!")
            print(f"⏱️  Total time: {analysis_time:.2f} seconds")
            print(f"🔍 Findings: {data['summary']['total_issues']}")
            print(f"📁 Files: {data['summary']['total_files']}")
            print(f"❌ Errors: {data['summary']['errors']}")
            
            if 'analysis_time' in data:
                print(f"🧠 Engine time: {data['analysis_time']}")
            
            print("\n📋 Sample findings:")
            for i, finding in enumerate(data['findings'][:3]):
                print(f"  {i+1}. {finding['severity']}: {finding['message']}")
            
            if len(data['findings']) > 3:
                print(f"  ... and {len(data['findings']) - 3} more")
                
        else:
            print(f"❌ API Error: {response.status_code}")
            print(f"📝 Response: {response.text}")
            
    except requests.exceptions.Timeout:
        print("⏰ Request timed out (>30s)")
    except requests.exceptions.ConnectionError:
        print("🔌 Connection failed - is the server running?")
    except Exception as e:
        print(f"💥 Unexpected error: {e}")

if __name__ == "__main__":
    test_api_performance()